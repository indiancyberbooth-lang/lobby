"use client";

import {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";
import { useRouter } from "next/navigation";

// Define the shape of your user data
interface User {
  username: string;
  balance: number;
  currency_symbol?: string;
  telegram_link?: string;
  [key: string]: any;
}

// Define the shape of the context value
interface AuthContextType {
  isAuthenticated: boolean;
  user: User | null;
  isLoading: boolean;
  login: () => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();

  const logout = async () => {
    try {
      // Hit the backend endpoint to clear the HttpOnly cookie
      await fetch(`/api/v1/logout`, { method: "POST", credentials: "include" });
    } catch (e) {
      console.error("Logout API call failed, proceeding with client-side cleanup.", e);
    }
    setUser(null);
    router.push("/login");
  };

  const refreshUser = async () => {
    try {
      const res = await fetch(`/api/v1/profile`, {
        credentials: "include",
      });

      if (res.status === 401 || res.status === 403) {
        setUser(null);
        return;
      }

      const data = await res.json().catch(() => ({}));
      if (res.ok && data.success && data.user) {
        setUser(data.user);
      }
    } catch (error) {
      console.error("Failed to refresh user profile:", error);
    }
  };

  useEffect(() => {
    const initAuth = async () => {
      // Always attempt to refresh on load to validate the HttpOnly session cookie
      await refreshUser();
      setIsLoading(false);
    }
    initAuth();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = async () => {
    // CRITICAL: Force a fetch to get the FULL profile (with real balance) from /api/v1/profile
    await refreshUser(); 
  };

  const value = { isAuthenticated: !!user, user, isLoading, login, logout, refreshUser };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

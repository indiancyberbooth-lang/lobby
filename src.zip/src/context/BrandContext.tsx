"use client";

import React, { createContext, useContext } from 'react';

interface BrandContextType {
  brandName: string;
  logoUrl: string | null;
  faviconUrl: string | null;
}

const BrandContext = createContext<BrandContextType>({
  brandName: '', // Default fallback
  logoUrl: null,
  faviconUrl: null,
});

export function BrandProvider({ 
  children, 
  brandName, 
  logoUrl,
  faviconUrl 
}: { 
  children: React.ReactNode; 
  brandName: string; 
  logoUrl: string | null; 
  faviconUrl: string | null;
}) {
  return (
    <BrandContext.Provider value={{ brandName, logoUrl, faviconUrl }}>
      {children}
    </BrandContext.Provider>
  );
}

export const useBrand = () => useContext(BrandContext);
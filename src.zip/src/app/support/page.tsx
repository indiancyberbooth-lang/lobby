"use client";

import { useState, useEffect, useRef, ChangeEvent } from "react";
import { useRouter } from "next/navigation";
import io from "socket.io-client";
import { useAuth } from "@/context/AuthContext";
import { ArrowLeft, Paperclip, SendHorizontal, X } from "lucide-react";

interface Message {
  id: string;
  message: string;
  sender: "user" | "admin";
  created_at: string;
  image_path?: string;
}

type AgentStatus = "online" | "offline" | "reconnecting";

const agentAvatarUrl = `https://api.dicebear.com/7.x/bottts/svg?seed=support-agent&backgroundColor=0a0a0f&radius=10`;

export default function SupportPage() {
  const router = useRouter();
  const { token, logout } = useAuth();
  const [socket, setSocket] = useState<ReturnType<typeof io> | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [agentStatus, setAgentStatus] = useState<AgentStatus>("offline");
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  const chatContainerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  // Fetch history and initialize WebSocket
  useEffect(() => {
    if (!token) return;

    // 1. Fetch chat history
    const fetchHistory = async () => {
      try {
        const res = await fetch(`/api/v1/users/support/history`, {
          credentials: "include",
        });
        if (res.ok) {
          const result = await res.json();
          if (result.success) setMessages(result.data);
        }
      } catch (error) {
        console.error("Failed to fetch chat history:", error);
      } finally {
        setIsLoadingHistory(false);
      }
    };

    fetchHistory();

    // 2. Initialize WebSocket connection
    const newSocket = io('/', {
      path: '/api/support/ws',
      auth: { token },
      reconnectionAttempts: 5,
    });

    newSocket.on("connect", () => setAgentStatus("online"));
    newSocket.on("disconnect", () => setAgentStatus("offline"));
    newSocket.on("reconnecting", () => setAgentStatus("reconnecting"));
    
    newSocket.on("message", (data: any) => {
      if (data.type === 'new_message') {
        setMessages((prev) => [...prev, data.payload]);
      }
      if (data.type === 'agent_status') {
        setAgentStatus(data.isOnline ? "online" : "offline");
      }
    });

    newSocket.on("connect_error", (error: Error) => {
      if (error.message.includes("Authentication") || error.message.includes("jwt")) {
        if (logout) logout();
      }
    });

    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  }, [token]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !socket) return;

    socket.emit("message", { type: 'user_message', text: newMessage, image: null });

    const localMessage: Message = {
      id: `user-${Date.now()}`,
      message: newMessage,
      sender: "user",
      created_at: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, localMessage]);
    setNewMessage("");
  };

  const handleFileUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !socket) return;

    const formData = new FormData();
    formData.append("image", file);

    try {
      const res = await fetch(`/api/support/upload`, {
        method: "POST",
        credentials: "include",
        body: formData,
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          socket.emit("message", { type: 'user_message', text: "", image: data.url });
          
          const localMessage: Message = {
            id: `user-img-${Date.now()}`,
            message: "",
            sender: "user",
            created_at: new Date().toISOString(),
            image_path: data.url,
          };
          setMessages((prev) => [...prev, localMessage]);
        }
      }
    } catch (error) {
      console.error("Image upload failed:", error);
    }
  };

  const statusIndicator: Record<AgentStatus, { color: string; text: string }> = {
    online: { color: "bg-green-500", text: "Live" },
    offline: { color: "bg-red-500", text: "Offline" },
    reconnecting: { color: "bg-yellow-500", text: "Connecting..." },
  };

  return (
    <div className="flex h-screen flex-col bg-bg-dark">
      {/* Header */}
      <header className="sticky top-0 z-20 flex flex-shrink-0 items-center gap-3 border-b border-white/10 bg-bg-card/80 p-3 backdrop-blur-lg">
        <button onClick={() => router.back()} className="text-text-dim hover:text-white">
          <ArrowLeft size={24} />
        </button>
        <img src={agentAvatarUrl} alt="Agent" className="h-9 w-9 rounded-full border-2 border-gold" />
        <div>
          <h1 className="text-sm font-bold leading-tight text-white">VIP Support</h1>
          <div className="flex items-center gap-1.5">
            <div className={`h-2 w-2 rounded-full ${statusIndicator[agentStatus].color}`}></div>
            <p className="text-[10px] text-text-dim">{statusIndicator[agentStatus].text}</p>
          </div>
        </div>
      </header>

      {/* Chat Area */}
      <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {isLoadingHistory && <div className="text-center text-text-dim">Loading history...</div>}
        
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[75%] rounded-2xl p-3 ${
              msg.sender === 'user'
                ? 'bg-gradient-to-r from-gold to-accent text-black rounded-tr-none'
                : 'bg-bg-card border border-white/10 text-white rounded-tl-none'
            }`}>
              {msg.image_path ? (
                <img src={msg.image_path} alt="Attachment" className="max-h-60 rounded-lg cursor-pointer object-cover" onClick={() => setLightboxImage(msg.image_path!)} />
              ) : (
                <p className="text-sm whitespace-pre-wrap">{msg.message}</p>
              )}
              <p className={`mt-1.5 text-xs opacity-70 ${msg.sender === 'user' ? 'text-right' : 'text-left'}`}>
                {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Input Area */}
      <footer className="sticky bottom-0 z-20 p-4 bg-bg-dark/80 backdrop-blur-sm">
        <form onSubmit={handleSendMessage} className="flex items-center gap-2 rounded-full border border-white/10 bg-bg-card p-2 shadow-2xl shadow-black/50">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-dashed border-gold/40 text-text-dim transition-colors hover:bg-white/10 hover:text-white"
          >
            <Paperclip size={20} />
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*"
            className="hidden"
          />
          <input 
            type="text" 
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 bg-transparent px-2 text-white placeholder:text-text-dim focus:outline-none"
          />
          <button
            type="submit"
            className="flex h-10 w-10 items-center justify-center rounded-full bg-gold text-bg-dark transition-transform hover:scale-105 active:scale-95 disabled:opacity-50"
            disabled={!newMessage.trim()}
          >
            <SendHorizontal size={20} />
          </button>
        </form>
      </footer>

      {/* Lightbox Overlay */}
      {lightboxImage && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-sm"
          onClick={() => setLightboxImage(null)}
        >
          <button 
            className="absolute top-4 right-4 text-white hover:text-gold transition-colors"
            onClick={() => setLightboxImage(null)}
          >
            <X size={32} />
          </button>
          <img src={lightboxImage} alt="Fullscreen Attachment" className="max-h-full max-w-full rounded-lg object-contain" />
        </div>
      )}
    </div>
  );
}
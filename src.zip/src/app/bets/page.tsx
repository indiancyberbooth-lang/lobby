"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { Gamepad2, ChevronDown, Search, Trophy } from "lucide-react";

interface Bet {
  id: string | number;
  game_name?: string;
  match_id?: string;
  bet_amount: number;
  payout?: number;
  status?: "win" | "loss" | "pending";
  selection?: string;
  odds?: number | string;
  created_at: string;
}

export default function BetsPage() {
  const { token, user } = useAuth();
  const [bets, setBets] = useState<Bet[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Filter States
  const [activeTab, setActiveTab] = useState<"running" | "history">("running");
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | "sports" | "casino">("all");
  const [dateFilter, setDateFilter] = useState<"all" | "today" | "week" | "month">("all");

  useEffect(() => {
    const fetchBets = async () => {
      try {
        const res = await fetch(`/api/v1/bets/history?page=1&limit=100`, {
          credentials: "include",
        });
        const data = await res.json().catch(() => ({}));
        
        if (res.ok && data.success) {
          setBets(data.history || []);
        }
      } catch (error) {
        console.error("Failed to fetch bets:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchBets();
  }, [token]);

  // Derived state for filtering bets
  const filteredBets = bets.filter((bet) => {
    // Tab Filter
    if (activeTab === "running" && bet.status !== "pending") return false;
    if (activeTab === "history" && bet.status === "pending") return false;

    // Search Filter
    const q = searchQuery.toLowerCase();
    if (q) {
      const matchId = String(bet.id).toLowerCase().includes(q);
      const matchGame = bet.game_name?.toLowerCase().includes(q) || false;
      const matchMatchId = bet.match_id?.toLowerCase().includes(q) || false;
      if (!matchId && !matchGame && !matchMatchId) return false;
    }

    // Type Filter
    if (typeFilter === "sports" && !bet.match_id) return false;
    if (typeFilter === "casino" && bet.match_id) return false; // Assuming casino bets don't have match_id

    // Date Filter
    if (dateFilter !== "all") {
      const betDate = new Date(bet.created_at);
      const now = new Date();
      
      if (dateFilter === "today") {
        if (betDate.toDateString() !== now.toDateString()) return false;
      } else {
        const diffTime = Math.abs(now.getTime() - betDate.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (dateFilter === "week" && diffDays > 7) return false;
        if (dateFilter === "month" && diffDays > 30) return false;
      }
    }

    return true;
  });

  return (
    <div className="pt-2 pb-20">
      <div className="px-4">
        
        {/* Top Tab Switcher */}
        <div className="flex w-full rounded-full bg-bg-dark p-1 border border-white/10 shadow-inner mb-4">
          <button 
            onClick={() => setActiveTab("running")}
            className={`flex-1 rounded-full py-2.5 text-center text-sm font-bold transition-all ${activeTab === "running" ? "bg-gold text-black shadow-sm border border-gold/50" : "text-text-dim hover:text-white"}`}
          >
            RUNNING
          </button>
          <button 
            onClick={() => setActiveTab("history")}
            className={`flex-1 rounded-full py-2.5 text-center text-sm font-bold transition-all ${activeTab === "history" ? "bg-white/10 text-white shadow-sm border border-white/5" : "text-text-dim hover:text-white"}`}
          >
            HISTORY
          </button>
        </div>

        {/* Search & Filters */}
        <div className="mb-5 space-y-3">
          {/* Search */}
          <div className="relative">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-text-dim">
              <Search size={18} />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by ID or Game..."
              className="w-full rounded-xl border border-white/10 bg-bg-card py-3.5 pl-11 pr-4 text-sm font-semibold text-white placeholder:font-normal placeholder:text-text-dim focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
            />
          </div>

          {/* Dropdowns */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <select 
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value as any)}
                className="h-11 w-full appearance-none rounded-xl border border-white/10 bg-bg-card pl-3 pr-8 text-xs font-semibold text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              >
                <option value="all">All Categories</option>
                <option value="sports">Sports</option>
                <option value="casino">Casino</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-text-dim"><ChevronDown size={14} /></div>
            </div>
            <div className="relative flex-1">
              <select 
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value as any)}
                className="h-11 w-full appearance-none rounded-xl border border-white/10 bg-bg-card pl-3 pr-8 text-xs font-semibold text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              >
                <option value="all">All Time</option>
                <option value="today">Today</option>
                <option value="week">Past 7 Days</option>
                <option value="month">Past 30 Days</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-text-dim"><ChevronDown size={14} /></div>
            </div>
          </div>
        </div>

        {/* Bets List */}
        <div className="space-y-3">
          {isLoading ? (
            <div className="text-center py-10 text-text-dim text-sm font-semibold">Loading bets...</div>
          ) : filteredBets.length === 0 ? (
            <div className="text-center py-10 text-text-dim text-sm bg-bg-dark rounded-xl border border-white/5">No bets found for this filter.</div>
          ) : (
            filteredBets.map((bet, index) => {
              const isWin = bet.status === "win" || (bet.payout && bet.payout > 0);
              const isLoss = bet.status === "loss" || (!isWin && bet.status !== "pending");
              const isPending = bet.status === "pending";
              const isSports = !!bet.match_id;
              
              return (
                <div key={bet.id || index} className="flex items-center justify-between rounded-xl bg-bg-card p-4 border border-white/5 hover:bg-white/5 transition-colors cursor-pointer">
                  <div className="flex items-center gap-3">
                    <div className={`flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg ${isWin ? 'bg-green-500/20 text-green-500' : isLoss ? 'bg-red-500/20 text-red-500' : isPending ? 'bg-gold/20 text-gold' : 'bg-white/10 text-white'}`}>
                      {isSports ? <Trophy size={18} /> : <Gamepad2 size={18} />}
                    </div>
                    <div className="overflow-hidden">
                      <p className="font-bold text-sm text-white truncate w-36 sm:w-48">{bet.game_name || bet.match_id || "Unknown Game"}</p>
                      <p className="text-[10px] text-text-dim mt-0.5">
                        {new Date(bet.created_at).toLocaleString(undefined, {
                          year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
                        })}
                      </p>
                      {isPending && bet.selection && (
                        <p className="text-[10px] font-bold text-white mt-1.5 uppercase tracking-wider bg-white/5 inline-block px-1.5 py-0.5 rounded">
                          {bet.selection} <span className="text-gold">@ {bet.odds}</span>
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    {isPending ? (
                      <p className="font-black text-xs text-gold animate-pulse tracking-widest uppercase">WAITING...</p>
                    ) : (
                      <p className={`font-bold text-sm ${isWin ? 'text-green-500' : isLoss ? 'text-red-500' : 'text-white'}`}>
                      {isWin ? '+' : isLoss ? '-' : ''}{user?.currency_symbol || '₹'}{isWin ? (bet.payout || 0).toLocaleString() : bet.bet_amount.toLocaleString()}
                      </p>
                    )}
                  <p className="text-[10px] text-text-dim font-medium uppercase tracking-wider mt-1">Bet: {user?.currency_symbol || '₹'}{bet.bet_amount}</p>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
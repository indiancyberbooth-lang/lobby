"use client";

import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Mail, Lock, User, UserPlus, ArrowRight, Phone, AlertCircle } from "lucide-react";
import { useBrand } from "@/context/BrandContext";

interface Country {
  iso2_code: string;
  name: string;
  flag: string;
  phone_code: string;
}

const FALLBACK_COUNTRIES: Country[] = [
  { iso2_code: "IN", name: "India", flag: "🇮🇳", phone_code: "+91" },
  { iso2_code: "US", name: "United States", flag: "🇺🇸", phone_code: "+1" },
  { iso2_code: "GB", name: "United Kingdom", flag: "🇬🇧", phone_code: "+44" },
  { iso2_code: "AU", name: "Australia", flag: "🇦🇺", phone_code: "+61" },
  { iso2_code: "CA", name: "Canada", flag: "🇨🇦", phone_code: "+1" },
];

function RegisterForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { brandName, logoUrl } = useBrand();
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [countries, setCountries] = useState<Country[]>([]);
  
  const [formData, setFormData] = useState({
    username: "",
    password: "",
    phone: "",
    email: "",
    referred_by: "",
    country_code: "",
    country: "",
    device_id: "",
  });

  // Initialization Effect (Device ID, Ref Code, Countries, Geo-IP)
  useEffect(() => {
    function getDeviceID() {
      var navigator_info: any = window.navigator;
      var screen_info: any = window.screen;
      var uid = navigator_info.mimeTypes ? navigator_info.mimeTypes.length : '';
      uid += navigator_info.userAgent.replace(/\D+/g, '');
      uid += navigator_info.plugins ? navigator_info.plugins.length : '';
      uid += screen_info.height || '';
      uid += screen_info.width || '';
      uid += screen_info.pixelDepth || '';
      return String(uid); 
    }

    // 1. Generate/Retrieve Device Fingerprint
    let deviceId = localStorage.getItem("device_fingerprint");
    if (!deviceId) {
      deviceId = getDeviceID();
      localStorage.setItem("device_fingerprint", deviceId);
    }

    // 2. Grab Referral Code from URL
    const ref = searchParams.get("ref") || "";

    setFormData((prev) => ({
      ...prev,
      device_id: deviceId as string,
      referred_by: ref,
    }));

    // 3. Fetch Countries & Auto-Detect IP
    const initData = async () => {
      let fetchedCountries = FALLBACK_COUNTRIES;
      try {
        const res = await fetch(`/api/v1/utils/countries`);
        if (res.ok) {
          const data = await res.json();
          if (data.success && data.countries) {
            fetchedCountries = data.countries.map((c: any) => ({
              iso2_code: c.iso2_code,
              name: c.name,
              flag: c.flag,
              phone_code: c.phone_code,
            }));
          }
        }
      } catch (err) {
        console.warn("Using fallback countries.");
      }
      setCountries(fetchedCountries);

      try {
        const ipRes = await fetch("https://ipapi.co/json/");
        const ipData = await ipRes.json();
        if (ipData.country_code) {
          const detected = fetchedCountries.find((c) => c.iso2_code === ipData.country_code);
          if (detected) {
            setFormData((prev) => ({ ...prev, country_code: detected.phone_code, country: detected.name }));
          } else {
            setFormData((prev) => ({ ...prev, country_code: fetchedCountries[0].phone_code, country: fetchedCountries[0].name }));
          }
        }
      } catch (err) {
        setFormData((prev) => ({ ...prev, country_code: fetchedCountries[0].phone_code, country: fetchedCountries[0].name }));
      }
    };

    initData();
  }, [searchParams]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError("");
  };

  const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedIso = e.target.value;
    const selected = countries.find((c) => c.iso2_code === selectedIso);
    if (selected) {
      setFormData({ ...formData, country_code: selected.phone_code, country: selected.name });
      setError("");
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    const payload = {
      ...formData,
      referred_by: formData.referred_by || undefined,
      domain_mapped: typeof window !== "undefined" ? window.location.hostname : "",
    };

    try {
      const res = await fetch(`/api/v1/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      
      const data = await res.json().catch(() => ({}));

      if (res.ok || data.success) {
        router.push(`/verify?u=${formData.username}`);
      } else {
        setError(data.message || "Registration failed. Please try again.");
      }
    } catch (err) {
      setError("A network error occurred. Please check your connection.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="z-10 flex w-full max-w-sm flex-col items-center overflow-y-auto px-4 pb-10 pt-10 transition-all max-h-[100dvh]">
      <div className="w-full flex justify-center mb-6">
        {logoUrl ? (
          <img 
            src={logoUrl} 
            alt={brandName} 
            className="w-full max-w-[300px] h-auto mx-auto mb-8 object-contain drop-shadow-xl"
          />
        ) : (
          <h1 className="text-2xl font-black tracking-widest text-gold uppercase mb-4 text-center">
            {brandName}
          </h1>
        )}
      </div>

      {error && (
        <div className="mb-4 flex w-full items-center gap-2 rounded-xl border border-red-500/20 bg-red-500/10 p-3 text-sm font-semibold text-red-500">
          <AlertCircle size={18} />
          {error}
        </div>
      )}

      <form onSubmit={handleRegister} className="w-full space-y-3">
        <div className="space-y-1">
          <label className="text-xs font-semibold uppercase tracking-wider text-text-dim">Username</label>
          <div className="relative">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-text-dim">
              <User size={18} />
            </div>
            <input
              type="text"
              name="username"
              value={formData.username}
              onChange={handleChange}
              className="w-full rounded-xl border border-white/10 bg-bg-dark/50 py-2.5 pl-11 pr-4 text-white placeholder:text-text-dim/50 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              placeholder="username"
              required
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-semibold uppercase tracking-wider text-text-dim">Password</label>
          <div className="relative">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-text-dim">
              <Lock size={18} />
            </div>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="w-full rounded-xl border border-white/10 bg-bg-dark/50 py-2.5 pl-11 pr-4 text-white placeholder:text-text-dim/50 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              placeholder="••••••••"
              minLength={8}
              required
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-semibold uppercase tracking-wider text-text-dim">Country & Phone</label>
          <div className="flex gap-2">
            <div className="relative w-1/3">
              <select
                name="country_select"
                value={countries.find((c) => c.name === formData.country)?.iso2_code || ""}
                onChange={handleCountryChange}
                className="h-full w-full appearance-none rounded-xl border border-white/10 bg-bg-dark/50 py-2.5 pl-3 pr-8 text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              >
              {countries.map((c, index) => (
                <option key={c.iso2_code || index} value={c.iso2_code}>
                    {c.flag} {c.iso2_code}
                  </option>
                ))}
              </select>
            </div>
            <div className="relative w-2/3">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-text-dim text-sm font-bold">
                {formData.country_code}
              </div>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full rounded-xl border border-white/10 bg-bg-dark/50 py-2.5 pl-[3.5rem] pr-4 text-white placeholder:text-text-dim/50 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
                placeholder="9876543210"
                required
              />
            </div>
          </div>
        </div>

        <div className="space-y-1">
          <label className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-text-dim">
            <span>Email Address</span>
            <span className="text-[10px] text-text-dim/50 lowercase">(Optional)</span>
          </label>
          <div className="relative">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-text-dim">
              <Mail size={18} />
            </div>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full rounded-xl border border-white/10 bg-bg-dark/50 py-2.5 pl-11 pr-4 text-white placeholder:text-text-dim/50 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              placeholder="email"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-text-dim">
            <span>Referral Code</span>
            <span className="text-[10px] text-text-dim/50 lowercase">(Optional)</span>
          </label>
          <div className="relative">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-text-dim">
              <UserPlus size={18} />
            </div>
            <input
              type="text"
              name="referred_by"
              value={formData.referred_by}
              onChange={handleChange}
              className="w-full rounded-xl border border-white/10 bg-bg-dark/50 py-2.5 pl-11 pr-4 text-white placeholder:text-text-dim/50 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              placeholder="referral code"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="group mt-4 flex w-full items-center justify-center space-x-2 rounded-xl bg-gradient-to-r from-accent to-gold py-3 font-bold text-white shadow-lg shadow-accent/25 transition-all hover:scale-[1.02] hover:shadow-accent/40 active:scale-95 disabled:opacity-70"
        >
          <span>{isLoading ? "Creating Account..." : "Register Now"}</span>
          {!isLoading && <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />}
        </button>
      </form>

      <p className="mt-4 w-full text-center text-sm text-text-dim">
        Already have an account? <Link href="/login" className="font-semibold text-gold hover:underline">Login here</Link>
      </p>
    </div>
  );
}

export default function RegisterPage() {
  return (
    <div className="h-[100dvh] w-full overflow-hidden flex items-center justify-center bg-bg-dark fixed inset-0">
      <Suspense fallback={<div className="text-gold animate-pulse">Loading secure form...</div>}>
        <RegisterForm />
      </Suspense>
    </div>
  );
}
"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { Gift, Users, Wallet, Copy, CheckCircle, QrCode, Share2 } from "lucide-react";
import { useBrand } from "@/context/BrandContext";

export default function ReferPage() {
  const { token, user, logout } = useAuth();
  const { brandName } = useBrand();
  
  const [showQr, setShowQr] = useState(false);
  const [refLink, setRefLink] = useState("");
  const [teamSize, setTeamSize] = useState(0);
  const [totalEarned, setTotalEarned] = useState(0);
  const [copied, setCopied] = useState(false);

  const handleLogout = async () => {
    try {
      await fetch("/api/v1/users/logout", {
        method: "POST",
        credentials: "include",
      });
    } catch (err) {
      console.error("Logout request failed", err);
    } finally {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('username');
      }
      if (logout) logout();
      window.location.href = '/login';
    }
  };

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await fetch(`/api/v1/profile`, {
          credentials: "include",
        });

        if (res.status === 401 || res.status === 403) {
          console.warn("Session expired or unauthorized. Logging out...");
          handleLogout();
          return;
        }

        const data = await res.json().catch(() => ({}));
        if (res.ok && data.success && data.user) {
          const user = data.user;
          const code = user.referral_code || user.username;
          
          if (typeof window !== "undefined") {
            setRefLink(`${window.location.origin}/register?ref=${code}`);
          }
          
          setTeamSize(user.team_size || 0);
          setTotalEarned(user.total_earned || 0);
        }
      } catch (error) {
        console.error("Failed to fetch profile for referral:", error);
      }
    };

    fetchProfile();
  }, [token, logout]);

  const handleCopy = () => {
    if (!refLink) return;
    navigator.clipboard.writeText(refLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    if (!refLink) return;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent("Join me on " + brandName + "! " + refLink)}`, "_blank");
  };

  return (
    <div className="pb-10 pt-4 w-full max-w-full overflow-x-hidden">
      <div className="px-4 w-full max-w-full">
        {/* HERO BANNER */}
        <div className="bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#1e1b4b] to-black border border-white/5 rounded-2xl p-5 text-center mb-5 relative w-full overflow-hidden">
          <Gift size={40} className="text-gold mx-auto mb-3 animate-bounce" />
          <h2 className="text-white text-xl font-bold uppercase mb-1">Refer & Earn</h2>
          <p className="text-text-dim text-xs mb-4">Invite your friends and earn lifetime commission on every bet they place!</p>
          
          {/* Tier Box */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-3 text-left">
            <div className="flex justify-between text-[10px] font-bold text-text-dim uppercase tracking-wider mb-2">
              <span>Current Tier: Bronze</span>
              <span className="text-gold">Silver (50%)</span>
            </div>
            <div className="h-1.5 bg-black rounded-full overflow-hidden">
              <div className="h-full w-1/2 bg-gold shadow-[0_0_10px_rgba(251,191,36,0.5)]"></div>
            </div>
          </div>
        </div>

        {/* LINK BOX & QR CODE */}
        <div className="bg-bg-card p-4 rounded-xl border border-white/5 mb-5 w-full overflow-hidden">
          <div className="flex justify-between items-center">
            <span className="text-[10px] font-bold text-text-dim tracking-widest uppercase">Your Referral Link</span>
            <button onClick={() => setShowQr(!showQr)} className="text-[10px] text-gold flex items-center gap-1 cursor-pointer hover:opacity-80 transition-opacity">
              <QrCode size={12} /> {showQr ? "Hide QR" : "Show QR"}
            </button>
          </div>

          {showQr && refLink && (
            <div className="mt-4 pt-4 border-t border-dashed border-white/20 text-center animate-in fade-in zoom-in duration-300">
              <div className="inline-block p-2 bg-white rounded-xl">
                <img 
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(refLink)}`} 
                  alt="Referral QR Code" 
                  className="w-[150px] h-[150px] object-contain"
                />
              </div>
              <p className="text-[10px] text-text-dim mt-2 uppercase tracking-widest font-semibold">Scan to Register</p>
            </div>
          )}
          
          <div className="flex gap-2 bg-black p-1.5 rounded-lg border border-white/10 mt-3 w-full overflow-hidden">
            <input 
              type="text" 
              value={refLink} 
              readOnly 
              className="flex-1 w-full min-w-0 truncate bg-transparent border-none text-gold text-xs px-2 outline-none" 
            />
            <button 
              onClick={handleCopy} 
              className="shrink-0 bg-gold text-black rounded-md px-4 py-2 font-bold text-xs active:scale-95 transition-transform flex items-center gap-1"
            >
              {copied ? <CheckCircle size={14} /> : <Copy size={14} />}
              {copied ? "Copied!" : "Copy"}
            </button>
          </div>
        </div>

        {/* TEAM STATS GRID */}
        <div className="grid grid-cols-2 gap-3 mb-6 w-full overflow-hidden">
          <div className="bg-bg-card border border-white/5 p-4 rounded-xl relative overflow-hidden">
            <Users size={32} className="absolute top-2 right-2 opacity-30 text-gold" />
            <p className="text-[10px] font-bold text-text-dim tracking-wider uppercase mb-1">Total Team</p>
            <p className="text-xl sm:text-2xl font-black text-white truncate">{teamSize}</p>
          </div>
          <div className="bg-bg-card border border-white/5 p-4 rounded-xl relative overflow-hidden">
            <Wallet size={32} className="absolute top-2 right-2 opacity-30 text-gold" />
            <p className="text-[10px] font-bold text-text-dim tracking-wider uppercase mb-1">Total Earned</p>
            <p className="text-xl sm:text-2xl font-black text-green-500 truncate">{user?.currency_symbol || '₹'}{totalEarned.toLocaleString()}</p>
          </div>
        </div>

        {/* SHARE BUTTON */}
        <button 
          onClick={handleShare}
          className="w-full bg-gold text-black rounded-xl py-3.5 font-black text-sm uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-transform shadow-[0_0_15px_rgba(251,191,36,0.3)]"
        >
          <Share2 size={18} />
          Share on WhatsApp
        </button>
      </div>
    </div>
  );
}
"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import {
  ArrowDownCircle,
  ArrowUpCircle,
  ChevronRight,
  Crown,
  Headset,
  History,
  LogOut,
  Mail,
  Phone,
  RefreshCw,
  Send,
  Settings,
  Share2,
  Wallet,
} from "lucide-react";

interface UserProfile {
  username: string;
  balance: number;
  phone: string;
  email: string;
  referral_code: string;
  country: string;
  currency_code: string;
  currency_symbol?: string;
  vip_level: number;
  vip_points: number;
  status: string;
}

export default function ProfilePage() {
  const { token, logout } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const handleLogout = async () => {
    try {
      // Tell the backend to destroy the HTTP-Only cookie
      await fetch("/api/v1/logout", {
        method: "POST",
        credentials: "include",
      });
    } catch (err) {
      console.error("Logout request failed", err);
    } finally {
      // Clean up any residual non-secure items
      if (typeof window !== 'undefined') {
        localStorage.removeItem('username');
        localStorage.removeItem('adminToken'); // if still relevant
      }
      
      // Call the context's logout function to clear global state
      if (logout) logout();
      
      // Force a full page reload to the login page
      window.location.href = '/login';
    }
  };

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await fetch('/api/v1/profile', {
          credentials: 'include',
          headers: { 
            'Content-Type': 'application/json',
          }
        });

        if (res.status === 401 || res.status === 403) {
          console.warn("Session expired or unauthorized. Logging out...");
          handleLogout();
          return;
        }

        const data = await res.json().catch(() => ({}));
        if (res.ok && data.success && data.user) {
          setProfile(data.user);
        }
      } catch (error) {
        console.error("Failed to fetch profile", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchProfile();
  }, [token]);

  const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile?.username || "Guest"}&backgroundColor=b45309`;

  const menuGroups = [
    {
      title: "Finance & History",
      items: [
        { icon: RefreshCw, label: "Coin Transfer", href: "/transfer" },
        { icon: History, label: "Betting Records", href: "/bets" },
        { icon: Wallet, label: "Transaction History", href: "/transactions" },
      ],
    },
    {
      title: "Support & Social",
      items: [
        { icon: Share2, label: "Refer & Earn", href: "/refer" },
        { icon: Send, label: "Join Telegram", href: profile?.telegram_link || "#" },
        { icon: Headset, label: "24/7 Live Support", href: "/support" },
      ],
    },
    {
      title: "System",
      items: [{ icon: Settings, label: "Account Settings", href: "/settings" }],
    },
  ];

  if (isLoading) {
    return <div className="flex h-screen items-center justify-center text-gold">Loading Profile...</div>;
  }

  return (
    <div className="pb-10 pt-4">
      <div className="space-y-6 px-4">
        {/* Top User Info Section */}
        <section className="relative overflow-hidden rounded-2xl bg-bg-card border border-white/10 py-4 px-4 shadow-lg flex flex-col items-center text-center">
          <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-gold/10 blur-2xl"></div>
          
          {/* VIP Badge - Top Right */}
          <div className="absolute right-3 top-3 z-10 flex items-center gap-1 rounded-md bg-gold/20 px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-gold border border-gold/30 shadow-sm">
            <Crown size={12} /> VIP {profile?.vip_level}
          </div>

          {/* Centered Avatar & Info */}
          <div className="relative z-10 flex flex-col items-center">
            <div className="mb-1 h-14 w-14 overflow-hidden rounded-full border-2 border-gold bg-bg-dark shadow-[0_0_10px_rgba(251,191,36,0.2)]">
              <img src={avatarUrl} alt="Avatar" className="h-full w-full object-cover" />
            </div>
            
            <h2 className="text-base font-black text-white tracking-tight leading-tight">{profile?.username}</h2>
            <p className="mt-0 text-[10px] font-medium text-text-dim">
              {profile?.country} <span className="mx-1 opacity-50">|</span> {profile?.currency_code}
            </p>
            
            <div className="mt-1 flex flex-col items-center gap-0.5 text-[9px] text-text-dim/80">
              <span className="flex items-center gap-1"><Phone size={10} className="text-text-dim" /> {profile?.phone}</span>
              <span className="flex items-center gap-1"><Mail size={10} className="text-text-dim" /> {profile?.email}</span>
            </div>
          </div>
          
          {/* Refer ID Box */}
          <div className="relative z-10 mt-2 flex items-center justify-center gap-1 rounded-lg bg-white/5 py-1 px-3 border border-white/5">
            <span className="text-[10px] font-semibold text-text-dim">REFER ID:</span>
            <span className="font-mono text-[11px] font-bold text-gold tracking-wider">{profile?.referral_code}</span>
          </div>
        </section>

        {/* 3-Column Stats Grid */}
        <section className="grid grid-cols-3 gap-3">
          <div className="flex flex-col items-center justify-center rounded-xl bg-bg-card border border-white/5 py-4 shadow-md">
            <span className="text-xs text-text-dim mb-1">Balance</span>
            <span className="font-bold text-gold">
              {profile?.currency_symbol || '₹'}
              {profile?.balance?.toLocaleString()}
            </span>
          </div>
          <div className="flex flex-col items-center justify-center rounded-xl bg-bg-card border border-white/5 py-4 shadow-md">
            <span className="text-xs text-text-dim mb-1">VIP Points</span>
            <span className="font-bold text-white">{profile?.vip_points}</span>
          </div>
          <div className="flex flex-col items-center justify-center rounded-xl bg-bg-card border border-white/5 py-4 shadow-md">
            <span className="text-xs text-text-dim mb-1">Status</span>
            <span className="font-bold text-green-500">{profile?.status}</span>
          </div>
        </section>

        {/* Quick Action Buttons */}
        <section className="grid grid-cols-2 gap-4">
          <Link href="/deposit" className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-accent to-gold py-3.5 font-bold text-white shadow-lg shadow-accent/20 transition-transform active:scale-95">
            <ArrowDownCircle size={20} />
            Deposit
          </Link>
          <Link href="/withdraw" className="flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 py-3.5 font-bold text-white transition-colors hover:bg-white/10 active:scale-95">
            <ArrowUpCircle size={20} />
            Withdraw
          </Link>
        </section>

        {/* Grouped Vertical Menu List */}
        <div className="space-y-6">
          {menuGroups.map((group, gIndex) => (
            <section key={gIndex} className="flex flex-col">
              <h3 className="mb-3 px-4 text-[10px] font-bold uppercase tracking-wider text-text-dim">
                {group.title}
              </h3>
              <div className="flex flex-col">
                {group.items.map((item, index) => (
                  <div
                    key={item.href}
                    className={index !== group.items.length - 1 ? "border-b border-white/5" : ""}
                  >
                    <Link
                      href={item.href}
                      className="flex w-full cursor-pointer items-center justify-between px-4 py-3.5 transition-colors hover:bg-white/5 active:bg-white/10"
                    >
                      <div className="flex items-center gap-3 text-white">
                        <item.icon size={20} className="text-text-dim" />
                        <span className="text-sm font-medium">{item.label}</span>
                      </div>
                      <ChevronRight size={18} className="text-text-dim" />
                    </Link>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>

        <button onClick={handleLogout} className="flex w-full items-center justify-center gap-2 rounded-xl border border-red-500/20 bg-red-500/10 p-4 font-bold text-red-500 transition-colors hover:bg-red-500/20 active:scale-95">
          <LogOut size={20} />
          Sign Out
        </button>
      </div>
    </div>
  );
}
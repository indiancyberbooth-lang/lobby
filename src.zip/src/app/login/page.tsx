"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { User, Lock, ArrowRight } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useBrand } from "@/context/BrandContext";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();
  const { login, isAuthenticated } = useAuth();
  const { brandName, logoUrl } = useBrand();
  const isLoggingInRef = useRef(false);

  useEffect(() => {
    if (isAuthenticated && !isLoggingInRef.current) {
      router.push("/");
    }
  }, [isAuthenticated, router]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    isLoggingInRef.current = true;
    setIsLoading(true);
    setError("");

    try {
      const response = await fetch(`/api/v1/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ identifier: email, password }),
      });
      const data = await response.json();

      if (response.ok && data.status === 'success') {
        await login({
          username: data.username || "Player",
          balance: data.balance ?? 0,
        });

        if (data.isAdmin) {
          window.location.href = data.redirect || `/admin`;
        } else {
          router.push(data.redirect || '/');
        }
      } else {
        isLoggingInRef.current = false;
        setError(data.msg || data.message || "Login failed");
        setIsLoading(false);
      }
    } catch (err) {
      isLoggingInRef.current = false;
      console.error("Login Error:", err);
      setError("An error occurred during login. Please try again.");
      setIsLoading(false);
    }
  };

  return (
    <div className="h-[100dvh] w-full overflow-hidden flex items-center justify-center bg-bg-dark fixed inset-0">
      {/* Form Container */}
      <div className="z-10 flex w-full max-w-sm flex-col items-center overflow-y-auto px-4 pb-10 pt-10 transition-all max-h-[100dvh]">
        <div className="w-full flex justify-center mb-8">
          {logoUrl ? (
            <img 
              src={logoUrl} 
              alt={brandName} 
              className="w-full max-w-[300px] h-auto mx-auto mb-8 object-contain drop-shadow-xl"
            />
          ) : (
            <h1 className="text-2xl font-black tracking-widest text-gold uppercase mb-4 text-center">
              {brandName}
            </h1>
          )}
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-500 p-3 rounded-xl text-xs font-bold text-center mb-4 uppercase">
            {error}
          </div>
        )}
        <form onSubmit={handleLogin} className="w-full space-y-5">
          <div className="space-y-1">
            <label className="text-xs font-semibold uppercase tracking-wider text-text-dim">Username / Phone / Email</label>
            <div className="relative">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-text-dim">
                <User size={18} />
              </div>
              <input
                type="text"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-bg-dark/50 py-3 pl-11 pr-4 text-white placeholder:text-text-dim/50 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
                placeholder="Username / Phone / Email"
                required
              />
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold uppercase tracking-wider text-text-dim">Password</label>
              <a href="#" className="text-xs text-gold hover:underline">Forgot password?</a>
            </div>
            <div className="relative">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-text-dim">
                <Lock size={18} />
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-bg-dark/50 py-3 pl-11 pr-4 text-white placeholder:text-text-dim/50 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="group mt-6 flex w-full items-center justify-center space-x-2 rounded-xl bg-gradient-to-r from-accent to-gold py-3.5 font-bold text-white shadow-lg shadow-accent/25 transition-all hover:scale-[1.02] hover:shadow-accent/40 active:scale-95 disabled:opacity-70"
          >
            <span>{isLoading ? "Authenticating..." : "Login"}</span>
            {!isLoading && <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />}
          </button>
        </form>

        <p className="mt-6 w-full text-center text-sm text-text-dim">
          Don't have an account? <Link href="/register" className="font-semibold text-gold hover:underline">Register here</Link>
        </p>
      </div>
    </div>
  );
}
"use client";

import { useState, useEffect } from "react";
import { PageHeader } from "@/components/PageHeader";
import { useAuth } from "@/context/AuthContext";
import { ArrowRightLeft, User, CircleDollarSign, ShieldCheck } from "lucide-react";

export default function TransferPage() {
  const { user, setUser, refreshUser } = useAuth() as any;
  const [recipient, setRecipient] = useState("");
  const [amount, setAmount] = useState("");
  const [pin, setPin] = useState("");
  const [balance, setBalance] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [isError, setIsError] = useState(false);

  useEffect(() => {
    const fetchBalance = async () => {
      try {
        const res = await fetch('/api/v1/profile', {
          credentials: 'include'
        });
        
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.success && data.user) {
          setBalance(data.user.balance);
          if (setUser) setUser(data.user);
          if (refreshUser) refreshUser();
        }
      } catch (err) {
        console.error("Failed to fetch balance", err);
      }
    };

    fetchBalance();
  }, [setUser, refreshUser]);

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage("");
    setIsError(false);

    try {
      const res = await fetch('/api/v1/transfer/submit', {
        method: 'POST',
        credentials: 'include',
        headers: { 
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ receiver: recipient, amount, pin })
      });
      const data = await res.json().catch(() => ({}));

      if (res.ok && (data.success || data.status === 'success')) {
        setIsError(false);
        setMessage(data.message || "Transfer successful.");
        setRecipient("");
        setAmount("");
        setPin("");
        setBalance((prev) => (prev !== null ? prev - Number(amount) : null));
        if (refreshUser) await refreshUser();
      } else {
        setIsError(true);
        setMessage(data.message || "Transfer failed.");
      }
    } catch (err) {
      setIsError(true);
      setMessage("A network error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="pb-10 pt-1">
      <PageHeader title="Coin Transfer" showBackButton={true} />

      <div className="space-y-6 px-4">
        {/* Balance Card */}
        <div className="flex items-center justify-between rounded-xl bg-gradient-to-r from-bg-card to-bg-dark border border-white/10 p-5 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white/10 text-gold">
              <ArrowRightLeft size={24} />
            </div>
            <div>
              <p className="text-sm text-text-dim">Available Balance</p>
              <p className="text-2xl font-bold text-white">
            {user?.currency_symbol || "₹"}{balance !== null ? balance.toLocaleString() : "..."}
              </p>
            </div>
          </div>
        </div>

        {/* Transfer Form */}
        <form onSubmit={handleTransfer} className="space-y-4 mt-4">
          {message && (
            <div className={`p-3 rounded-xl text-xs font-bold text-center uppercase border ${isError ? 'bg-red-500/10 border-red-500/20 text-red-500' : 'bg-green-500/10 border-green-500/20 text-green-500'}`}>
              {message}
            </div>
          )}

          <div className="space-y-1">
            <label className="text-xs font-semibold uppercase tracking-wider text-text-dim">Recipient Username</label>
            <div className="relative">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-text-dim">
                <User size={18} />
              </div>
              <input
                type="text"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-bg-dark/50 py-3 pl-11 pr-4 text-white placeholder:text-text-dim/50 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
                placeholder="username"
                required
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold uppercase tracking-wider text-text-dim">Transfer Amount</label>
            <div className="relative">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-text-dim">
                <CircleDollarSign size={18} />
              </div>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-bg-dark/50 py-3 pl-11 pr-4 text-white placeholder:text-text-dim/50 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
                placeholder="0.00"
                required
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold uppercase tracking-wider text-text-dim">Security PIN</label>
            <div className="relative">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-text-dim">
                <ShieldCheck size={18} />
              </div>
              <input
                type="password"
                maxLength={4}
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-bg-dark/50 py-3 pl-11 pr-4 text-white placeholder:text-text-dim/50 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
                placeholder="••••"
                required
              />
            </div>
          </div>

          <button 
            type="submit"
            disabled={isLoading}
            className="w-full rounded-xl bg-gradient-to-r from-accent to-gold py-4 font-bold text-white shadow-lg shadow-accent/25 hover:scale-[1.02] active:scale-95 transition-all mt-6 disabled:opacity-70 disabled:hover:scale-100"
          >
            {isLoading ? "Processing..." : "Confirm Transfer"}
          </button>
        </form>
      </div>
    </div>
  );
}

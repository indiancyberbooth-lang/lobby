"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { Copy, CheckCircle, IndianRupee, Receipt, Info } from "lucide-react";
import { useBrand } from "@/context/BrandContext";

export default function DepositPage() {
  const { user, refreshUser } = useAuth();
  const { brandName } = useBrand();
  
  const [payMethod, setPayMethod] = useState("upi");
  const [amount, setAmount] = useState("");
  const [refNumber, setRefNumber] = useState("");
  
  const [message, setMessage] = useState("");
  const [isError, setIsError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedItem, setCopiedItem] = useState<string | null>(null);

  // Dynamic Settings States
  const [currentRate, setCurrentRate] = useState(1);
  const [userSymbol, setUserSymbol] = useState("₹");
  const [bufferPercent, setBufferPercent] = useState(0);
  const [adminUpi, setAdminUpi] = useState("");
  const [usdtAddress, setUsdtAddress] = useState("");
  const [payLink, setPayLink] = useState("");
  const [hasBank, setHasBank] = useState(false);
  const [hasUpi, setHasUpi] = useState(false);
  const [hasUsdt, setHasUsdt] = useState(false);
  const [bankDetails, setBankDetails] = useState<any>(null);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const res = await fetch(`/api/v1/deposit/settings`, {
          credentials: "include",
        });
        const data = await res.json().catch(() => ({}));
        
        if (res.ok && data.success) {
          setCurrentRate(data.current_rate || 1);
          setUserSymbol(data.user_symbol || "₹");
          setBufferPercent(data.buffer_percent || 0);
          setAdminUpi(data.admin_upi || "");
          setUsdtAddress(data.usdt_address || "");
          setPayLink(data.pay_link || "");
          
          // Dynamic visibility flags
          setHasUpi(!!data.has_upi);
          setHasBank(!!data.has_bank);
          setHasUsdt(!!data.has_usdt);
          setBankDetails(data.bank_details || null);

          // Auto-select the first available method
          if (data.has_upi) setPayMethod('upi');
          else if (data.has_bank) setPayMethod('bank');
          else if (data.has_usdt) setPayMethod('usdt');
        }
      } catch (error) {
        console.error("Failed to fetch deposit settings:", error);
      }
    };

    fetchSettings();
  }, []);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedItem(id);
    setTimeout(() => setCopiedItem(null), 2000);
  };

  const handleDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage("");
    setIsError(false);

    if (!amount || Number(amount) <= 0) {
      setIsError(true);
      setMessage("Enter a valid deposit amount.");
      setIsLoading(false);
      return;
    }
    if (!refNumber.trim()) {
      setIsError(true);
      setMessage("Enter the UTR or Transaction ID.");
      setIsLoading(false);
      return;
    }

    try {
      const res = await fetch(`/api/v1/deposit/submit`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({ amount, pay_method: payMethod, ref_number: refNumber }),
      });
      const data = await res.json().catch(() => ({}));

      if (res.ok && (data.success || data.status === "success")) {
        setIsError(false);
        setMessage(data.message || "Deposit request submitted successfully. Awaiting verification.");
        setAmount("");
        setRefNumber("");
        if (refreshUser) await refreshUser();
      } else {
        setIsError(true);
        setMessage(data.message || "Failed to submit deposit.");
      }
    } catch (err) {
      setIsError(true);
      setMessage("A network error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const numericAmount = Number(amount) || 0;
  const calculatedCoins = (numericAmount * currentRate * (1 + bufferPercent / 100)).toFixed(2);

  const upiQrData = `upi://pay?pa=${adminUpi}&pn=${encodeURIComponent(brandName)}`;

  return (
    <div className="pb-10 pt-2 px-4">
      {/* Tab Switcher */}
      <div className="flex w-full rounded-full bg-bg-dark p-1 border border-white/10 shadow-inner mb-6">
          <div className="flex-1 rounded-full bg-gold py-2.5 text-center text-sm font-bold text-black shadow-sm border border-gold/50">
            Deposit
          </div>
          <Link href="/withdraw" replace className="flex-1 rounded-full py-2.5 text-center text-sm font-semibold text-text-dim transition-colors hover:text-white">
            Withdraw
          </Link>
        </div>

      <div className="space-y-6">
        {message && (
          <div className={`p-3 rounded-xl text-xs font-bold text-center uppercase border ${isError ? 'bg-red-500/10 border-red-500/20 text-red-500' : 'bg-green-500/10 border-green-500/20 text-green-500'}`}>
            {message}
          </div>
        )}

        <form onSubmit={handleDeposit} className="space-y-6">
          {/* Method Selector */}
          <section>
            <h2 className="mb-3 text-sm font-semibold text-text-dim">Deposit Method</h2>
            <div className="flex gap-2 rounded-xl bg-bg-dark p-1.5 border border-white/5">
              {hasUpi && (
                <button type="button" onClick={() => setPayMethod("upi")} className={`flex-1 rounded-lg py-2.5 text-xs font-bold transition-all ${payMethod === "upi" ? "bg-gold text-black shadow-md" : "text-text-dim hover:text-white"}`}>UPI</button>
              )}
              {hasBank && (
                <button type="button" onClick={() => setPayMethod("bank")} className={`flex-1 rounded-lg py-2.5 text-xs font-bold transition-all ${payMethod === "bank" ? "bg-gold text-black shadow-md" : "text-text-dim hover:text-white"}`}>Bank</button>
              )}
              {hasUsdt && (
                <button type="button" onClick={() => setPayMethod("usdt")} className={`flex-1 rounded-lg py-2.5 text-xs font-bold transition-all ${payMethod === "usdt" ? "bg-gold text-black shadow-md" : "text-text-dim hover:text-white"}`}>USDT</button>
              )}
            </div>
          </section>

          {/* Dynamic Payment Details Display */}
          <section className="bg-bg-card border border-white/10 rounded-xl p-4 shadow-lg flex flex-col items-center">
            {payMethod === "usdt" && (
              <>
                {bufferPercent > 0 && (
                  <div className="w-full bg-green-500/10 text-green-500 border border-green-500/20 p-2.5 rounded-lg text-xs font-bold text-center mb-4 uppercase tracking-wide">
                    USDT Special: Get {bufferPercent}% Extra Balance Automatically!
                  </div>
                )}
                <img 
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(usdtAddress)}`} 
                  alt="USDT TRC20 QR Code" 
                  className="w-32 h-32 object-contain bg-white p-2 rounded-xl mb-4 shadow-[0_0_15px_rgba(251,191,36,0.15)]"
                />
                <p className="text-xs text-text-dim uppercase tracking-widest font-semibold mb-1.5">Official USDT (TRC20) Address</p>
                <div className="w-full flex items-center gap-2 bg-bg-dark border border-white/5 p-2.5 rounded-lg">
                  <span className="flex-1 text-gold text-xs font-mono truncate">{usdtAddress}</span>
                  <button type="button" onClick={() => handleCopy(usdtAddress, "usdt")} className="text-text-dim hover:text-white transition-colors">
                    {copiedItem === "usdt" ? <CheckCircle size={16} className="text-green-500" /> : <Copy size={16} />}
                  </button>
                </div>
              </>
            )}

            {payMethod === "upi" && (
              <>
                <img 
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(upiQrData)}`} 
                  alt="UPI QR Code" 
                  className="w-32 h-32 object-contain bg-white p-2 rounded-xl mb-4 shadow-[0_0_15px_rgba(251,191,36,0.15)]"
                />
                <p className="text-xs text-text-dim uppercase tracking-widest font-semibold mb-1.5">Official UPI ID</p>
                <div className="w-full flex items-center gap-2 bg-bg-dark border border-white/5 p-2.5 rounded-lg">
                  <span className="flex-1 text-white text-sm font-semibold truncate text-center">{adminUpi}</span>
                  <button type="button" onClick={() => handleCopy(adminUpi, "upi")} className="text-text-dim hover:text-white transition-colors">
                    {copiedItem === "upi" ? <CheckCircle size={16} className="text-green-500" /> : <Copy size={16} />}
                  </button>
                </div>
              </>
            )}

            {payMethod === 'bank' && bankDetails && (
              <div className="space-y-3 rounded-xl bg-white/5 p-4 border border-white/10 w-full">
                <p className="text-xs text-text-dim uppercase">Bank Transfer Details</p>
                <div className="space-y-2">
                  <div className="flex justify-between"><span className="text-text-dim text-sm">Account Name:</span> <span className="text-white font-bold">{bankDetails.holder_name}</span></div>
                  <div className="flex justify-between"><span className="text-text-dim text-sm">Bank Name:</span> <span className="text-white font-bold">{bankDetails.bank_name}</span></div>
                  <div className="flex justify-between"><span className="text-text-dim text-sm">Account Number:</span> <span className="text-gold font-mono">{bankDetails.account_number}</span></div>
                  <div className="flex justify-between"><span className="text-text-dim text-sm">IFSC/SWIFT:</span> <span className="text-gold font-mono">{bankDetails.ifsc}</span></div>
                </div>
              </div>
            )}
          </section>

          {/* Deposit Form Inputs */}
          <section className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold uppercase tracking-wider text-text-dim">Deposit Amount</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-gold font-bold text-lg">
                  {payMethod === "usdt" ? "USDT" : (user?.currency_symbol || userSymbol)}
                </div>
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={amount}
                  onKeyDown={(e) => {
                    if (e.key === '-' || e.key === '+' || e.key === 'e' || e.key === 'E') {
                      e.preventDefault();
                    }
                  }}
                  onChange={(e) => setAmount(e.target.value)}
                  className={`w-full rounded-xl border border-white/10 bg-bg-card py-4 pr-4 text-xl font-bold text-white placeholder:font-normal placeholder:text-text-dim focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold ${payMethod === 'usdt' ? 'pl-20' : 'pl-12'}`}
                  placeholder="0.00"
                  required
                />
              </div>
              
              {/* Dynamic Crypto Calculation Box */}
              {payMethod === "usdt" && numericAmount > 0 && (
                <div className="rounded-lg bg-bg-card p-3 border border-white/5 shadow-inner mt-2">
                  <div className="flex justify-between text-sm text-text-dim mb-1">
                    <span>Base Conversion ({currentRate}):</span>
                    <span>{userSymbol}{(numericAmount * currentRate).toFixed(2)}</span>
                  </div>
                  {bufferPercent > 0 && (
                    <div className="flex justify-between text-sm text-green-400 mb-1">
                      <span>Bonus ({bufferPercent}%):</span>
                      <span>+ {userSymbol}{(numericAmount * currentRate * (bufferPercent / 100)).toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between border-t border-white/10 pt-2 font-bold text-white">
                    <span>Total Coins to Receive:</span>
                    <span className="text-gold">{userSymbol}{calculatedCoins}</span>
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-1.5 mt-4">
              <label className="text-xs font-semibold uppercase tracking-wider text-text-dim flex items-center justify-between">
                <span>UTR / Transaction ID</span>
                <span className="text-[10px] lowercase text-text-dim/60 font-normal opacity-80">(12-digit Ref No.)</span>
              </label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-text-dim">
                  <Receipt size={18} />
                </div>
                <input
                  type="text"
                  value={refNumber}
                  onChange={(e) => setRefNumber(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-bg-card py-3.5 pl-11 pr-4 text-sm font-semibold text-white placeholder:font-normal placeholder:text-text-dim focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
                  placeholder="e.g. 312518XXXXXX"
                  required
                />
              </div>
            </div>
          </section>

          <button 
            type="submit" 
            disabled={isLoading || !amount || Number(amount) <= 0 || !refNumber.trim()}
            className="w-full rounded-xl bg-gradient-to-r from-accent to-gold py-4 font-bold text-white shadow-lg shadow-accent/25 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
          >
            {isLoading ? "Processing..." : "Verify Payment"}
          </button>
        </form>
      </div>
    </div>
  );
}
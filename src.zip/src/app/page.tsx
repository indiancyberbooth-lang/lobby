"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";

// Import MAHAKAAL Modular Lobby Components
import Sidebar from "@/components/Sidebar";
import Banner from "@/components/home/Banner";
import SportsGrid from "@/components/home/SportsGrid";
import GameGrid from "@/components/home/GameGrid";
import GameModal from "@/components/GameModal";
import LuckySpin from "@/app/luckyspin/page";

export default function LobbyPage() {
  const { isAuthenticated, refreshUser } = useAuth();
  const [gameUrl, setGameUrl] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState("live");

  useEffect(() => {
    const savedCategory = sessionStorage.getItem("activeCategory");
    if (savedCategory) {
      setActiveCategory(savedCategory);
    }
  }, []);

  const handleCategorySelect = (id: string) => {
    setActiveCategory(id);
    sessionStorage.setItem("activeCategory", id);
  };

  const QUANTUM_BASE = process.env.NEXT_PUBLIC_QUANTUM_API_URL || "http://localhost:4000";

  const launchRealGame = async (gameId: string) => {
    if (!isAuthenticated) {
      alert("Please log in to play.");
      return;
    }
    try {
      const res = await fetch(`${QUANTUM_BASE}/api/game/launch`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ gameId, operatorId: "default_operator" }),
      });
      
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || errorData.error || "Failed to launch game");
      }

      const data = await res.json();
      if (data.success && data.sessionToken) {
        const finalLaunchUrl = data.launch_url || `${QUANTUM_BASE}/play?session=${data.sessionToken}&balance=${data.balance}&currency=${data.currency || 'INR'}&game_id=${gameId}`;
        setGameUrl(finalLaunchUrl);
        setIsModalOpen(true);
      } else {
        throw new Error(data.error || "Failed to get session token!");
      }
    } catch (error: any) {
      console.error("Game launch error:", error);
      alert(error.message || "An error occurred while launching the game.");
    }
  };

  const closeModal = async () => {
    setIsModalOpen(false);
    setGameUrl(null);
    if (refreshUser) {
      await refreshUser();
    }
  };

  return (
    <>
      {/* Standard Scroll Layout */}
      <div className="flex min-h-screen w-full bg-bg-dark">
        <Sidebar activeCategory={activeCategory} onSelect={handleCategorySelect} />
        <main className="flex flex-col ml-[45px] w-[calc(100%-45px)] max-w-[calc(100%-45px)] overflow-y-auto overflow-x-hidden px-1.5 no-scrollbar">
          <div className="flex flex-col gap-6 py-2 pb-24 w-full">
            {(activeCategory === "live" || activeCategory === "sports") && <Banner />}
            
            {activeCategory === "sports" && <SportsGrid />}
            
            {(activeCategory === "slot" || activeCategory === "casino") && (
              <GameGrid category={activeCategory} onLaunchGame={launchRealGame} />
            )}
            
            {activeCategory === "mini-games" && (
              <div className="flex h-40 flex-col items-center justify-center rounded-xl border border-white/5 bg-bg-card shadow-lg">
                <span className="text-lg font-black tracking-widest text-gold opacity-50 uppercase">COMING SOON</span>
              </div>
            )}
            {activeCategory === "luckyspin" && (
              <LuckySpin />
            )}
          </div>
        </main>
      </div>

      {/* Fullscreen Quantum Game Modal */}
      {isModalOpen && gameUrl && (
        <GameModal gameUrl={gameUrl} onClose={closeModal} />
      )}
    </>
  );
}
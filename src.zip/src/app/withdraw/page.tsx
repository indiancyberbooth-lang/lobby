"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { Wallet, Info, ShieldCheck, Clock, AlertTriangle } from "lucide-react";

export default function WithdrawPage() {
  const { user, refreshUser } = useAuth();
  const [method, setMethod] = useState("upi");
  const [amount, setAmount] = useState("");
  
  // Dynamic form state
  const [formData, setFormData] = useState({
    fullName: "",
    upiId: "",
    accountHolder: "",
    bankName: "",
    accountNumber: "",
    ifsc: "",
    trc20Address: "",
  });

  // Dynamic method flags
  const [hasUpi, setHasUpi] = useState(false);
  const [hasBank, setHasBank] = useState(false);
  const [hasUsdt, setHasUsdt] = useState(false);
  const [usdtRate, setUsdtRate] = useState(90);
  const [pin, setPin] = useState("");
  const [pendingWithdraws, setPendingWithdraws] = useState<any[]>([]);
  const [cancelConfirmId, setCancelConfirmId] = useState<string | number | null>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [isError, setIsError] = useState(false);

  const fetchPendingWithdrawals = async () => {
    try {
      const res = await fetch(`/api/v1/history`, {
        credentials: "include"
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && (data.success || data.status === "success")) {
        const pendings = data.transactions.filter((tx: any) => tx.type === "withdraw" && tx.status === "pending");
        setPendingWithdraws(pendings);
      }
    } catch (error) { console.error(error); }
  };

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const res = await fetch(`/api/v1/deposit/settings`, {
          credentials: "include",
        });
        const data = await res.json().catch(() => ({}));
        
        if (res.ok && data.success) {
          setHasUpi(!!data.has_upi);
          setHasBank(!!data.has_bank);
          setHasUsdt(!!data.has_usdt);
          if (data.current_rate) setUsdtRate(data.current_rate);
          
          // Auto-select first available
          if (data.has_upi) setMethod('upi');
          else if (data.has_bank) setMethod('bank');
          else if (data.has_usdt) setMethod('usdt');
        }
      } catch (error) {
        console.error("Failed to fetch withdrawal settings:", error);
      }
    };

    fetchSettings();
    fetchPendingWithdrawals();
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage("");
    setIsError(false);

    if (!amount || Number(amount) <= 0) {
      setIsError(true);
      setMessage("Enter a valid withdrawal amount.");
      setIsLoading(false);
      return;
    }

    let payment_details = "";
    if (method === "bank") {
      payment_details = `BANK: ${formData.bankName} | ACC: ${formData.accountNumber} | IFSC: ${formData.ifsc}`;
    } else if (method === "upi") {
      payment_details = `UPI ID: ${formData.upiId} | NAME: ${formData.fullName}`;
    } else if (method === "usdt") {
      payment_details = `USDT TRC20: ${formData.trc20Address}`;
    }

    try {
      const res = await fetch(`/api/v1/withdraw/submit`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
        },
        credentials: "include",
        body: JSON.stringify({ amount, payment_details, pin })
      });
      const data = await res.json().catch(() => ({}));

      if (res.ok && (data.success || data.status === 'success')) {
        setIsError(false);
        setMessage(data.message || "Withdrawal request submitted successfully.");
        setAmount("");
        setFormData({ fullName: "", upiId: "", accountHolder: "", bankName: "", accountNumber: "", ifsc: "", trc20Address: "" });
        if (refreshUser) await refreshUser();
      } else {
        setIsError(true);
        setMessage(data.message || "Failed to submit withdrawal.");
      }
    } catch (err) {
      setIsError(true);
      setMessage("A network error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const executeCancel = async () => {
    if(!cancelConfirmId) return;
    try {
      const res = await fetch(`/api/v1/finance/withdraw/cancel`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
        },
        credentials: "include",
        body: JSON.stringify({ transaction_id: cancelConfirmId })
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        alert(data.message || "Withdrawal cancelled and refunded.");
        if (refreshUser) await refreshUser();
        fetchPendingWithdrawals(); // Refresh list
      } else {
        alert(data.message || "Failed to cancel withdrawal.");
      }
    } catch(err) {
      alert("Network error.");
    }
    setCancelConfirmId(null);
  };

  // Realtime fee calculation
  const numericAmount = Number(amount) || 0;
  const feeRate = method === "usdt" ? 0.02 : 0; // 2% for USDT, 0% for others
  const feeAmount = numericAmount * feeRate;
  const finalReceive = numericAmount - feeAmount;

  // Validate form based on selected method
  const isFormValid = (() => {
    if (method === "upi") return !!(formData.fullName.trim() && formData.upiId.trim());
    if (method === "bank") return !!(formData.bankName.trim() && formData.accountHolder.trim() && formData.accountNumber.trim() && formData.ifsc.trim());
    if (method === "usdt") return !!(formData.trc20Address.trim());
    return false;
  })();

  return (
    <div className="pb-10 pt-2 px-4">
      {/* Tab Switcher */}
      <div className="flex w-full rounded-full bg-bg-dark p-1 border border-white/10 shadow-inner mb-6">
          <Link href="/deposit" replace className="flex-1 rounded-full py-2.5 text-center text-sm font-semibold text-text-dim transition-colors hover:text-white">
            Deposit
          </Link>
          <div className="flex-1 rounded-full bg-white/10 py-2.5 text-center text-sm font-bold text-white shadow-sm border border-white/5">
            Withdraw
          </div>
        </div>

      <div className="space-y-6">
        {message && (
          <div className={`p-3 rounded-xl text-xs font-bold text-center uppercase border ${isError ? 'bg-red-500/10 border-red-500/20 text-red-500' : 'bg-green-500/10 border-green-500/20 text-green-500'}`}>
            {message}
          </div>
        )}

        <form onSubmit={handleWithdraw} className="space-y-6">
        {/* Method Selector */}
        <section>
          <h2 className="mb-3 text-sm font-semibold text-text-dim">
            Withdrawal Method
          </h2>
          <div className="flex gap-2 rounded-xl bg-bg-dark p-1.5 border border-white/5">
            {hasUpi && (
              <button type="button" onClick={() => setMethod("upi")} className={`flex-1 rounded-lg py-2.5 text-xs font-bold transition-all ${method === "upi" ? "bg-gold text-black shadow-md" : "text-text-dim hover:text-white"}`}>UPI</button>
            )}
            {hasBank && (
              <button type="button" onClick={() => setMethod("bank")} className={`flex-1 rounded-lg py-2.5 text-xs font-bold transition-all ${method === "bank" ? "bg-gold text-black shadow-md" : "text-text-dim hover:text-white"}`}>Bank</button>
            )}
            {hasUsdt && (
              <button type="button" onClick={() => setMethod("usdt")} className={`flex-1 rounded-lg py-2.5 text-xs font-bold transition-all ${method === "usdt" ? "bg-gold text-black shadow-md" : "text-text-dim hover:text-white"}`}>USDT</button>
            )}
          </div>
        </section>

        {/* Withdraw Amount */}
        <section>
          <h2 className="mb-3 text-sm font-semibold text-text-dim">
            Withdraw Amount
          </h2>
          <div className="relative">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-gold font-bold text-lg">
              {user?.currency_symbol || "₹"}
            </div>
            <input
              type="number"
              min="0"
              step="any"
              onKeyDown={(e) => { if (['-','+','e','E'].includes(e.key)) e.preventDefault(); }}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full rounded-xl border border-white/10 bg-bg-card py-4 pl-10 pr-20 text-xl font-bold text-white placeholder:font-normal placeholder:text-text-dim focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              placeholder="0.00"
            />
            <button 
              type="button"
              onClick={() => setAmount(user?.balance?.toString() || "0")}
              className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md bg-white/10 px-3 py-1.5 text-xs font-semibold text-gold hover:bg-white/20"
            >
              MAX
            </button>
          </div>

          {/* Dynamic Calculation Box */}
          {numericAmount > 0 && (
            <div className="mt-3 rounded-lg bg-bg-card p-3 border border-white/5">
              <div className="flex justify-between text-sm text-text-dim">
                <span>Withdraw Amount:</span>
                <span>{user?.currency_symbol || '₹'}{numericAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm text-red-400 mt-1">
                <span>Handling Fee ({feeRate * 100}%):</span>
                <span>- {user?.currency_symbol || '₹'}{feeAmount.toFixed(2)}</span>
              </div>
              
              {method === "usdt" ? (
                <>
                  <div className="mt-2 flex justify-between border-t border-white/10 pt-2 font-bold text-green-400">
                    <span>Final Receive (USDT):</span>
                    <span>{(finalReceive / usdtRate).toFixed(2)} USDT</span>
                  </div>
                  <div className="flex justify-between text-xs text-text-dim mt-1">
                    <span>Rate: 1 USDT = {user?.currency_symbol || '₹'}{usdtRate}</span>
                  </div>
                </>
              ) : (
                <div className="mt-2 flex justify-between border-t border-white/10 pt-2 font-bold text-green-400">
                  <span>Final Receive Amount:</span>
                  <span>{user?.currency_symbol || '₹'}{finalReceive.toFixed(2)}</span>
                </div>
              )}
            </div>
          )}
        </section>

        {/* Dynamic Forms */}
        <section className="space-y-4 rounded-xl border border-white/10 bg-bg-card p-5">
          <h2 className="text-sm font-semibold text-white mb-2">Account Details</h2>

          {method === "upi" && (
            <>
              <input
                type="text"
                name="fullName"
                value={formData.fullName}
                onChange={handleInputChange}
                placeholder="Full Name as per Bank"
                className="w-full rounded-lg border border-white/5 bg-bg-dark p-3 text-sm text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              />
              <input
                type="text"
                name="upiId"
                value={formData.upiId}
                onChange={handleInputChange}
                placeholder="UPI ID (e.g., name@okaxis)"
                className="w-full rounded-lg border border-white/5 bg-bg-dark p-3 text-sm text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              />
            </>
          )}

          {method === "bank" && (
            <>
              <input
                type="text"
                name="bankName"
                value={formData.bankName}
                onChange={handleInputChange}
                placeholder="Bank Name"
                className="w-full rounded-lg border border-white/5 bg-bg-dark p-3 text-sm text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              />
              <input
                type="text"
                name="accountHolder"
                value={formData.accountHolder}
                onChange={handleInputChange}
                placeholder="Account Holder Name"
                className="w-full rounded-lg border border-white/5 bg-bg-dark p-3 text-sm text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              />
              <input
                type="text"
                name="accountNumber"
                value={formData.accountNumber}
                onChange={handleInputChange}
                placeholder="Account Number"
                className="w-full rounded-lg border border-white/5 bg-bg-dark p-3 text-sm text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              />
              <input
                type="text"
                name="ifsc"
                value={formData.ifsc}
                onChange={handleInputChange}
                placeholder="IFSC Code"
                className="w-full rounded-lg border border-white/5 bg-bg-dark p-3 text-sm text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              />
            </>
          )}

          {method === "usdt" && (
            <input
              type="text"
              name="trc20Address"
              value={formData.trc20Address}
              onChange={handleInputChange}
              placeholder="TRC20 Wallet Address"
              className="w-full rounded-lg border border-white/5 bg-bg-dark p-3 text-sm text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
            />
          )}
        </section>

        {/* Security PIN */}
        <section className="space-y-4 rounded-xl border border-white/10 bg-bg-card p-5">
          <h2 className="text-sm font-semibold text-white mb-2 flex items-center gap-2">
            Security PIN
          </h2>
          <div className="relative">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-text-dim">
              <ShieldCheck size={18} />
            </div>
            <input
              type="password"
              maxLength={4}
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
              className="w-full rounded-xl border border-white/10 bg-bg-dark/50 py-3 pl-11 pr-4 text-white placeholder:text-text-dim/50 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
              placeholder="••••"
              required
            />
          </div>
        </section>

        <button 
          type="submit" 
          disabled={isLoading || !amount || Number(amount) <= 0 || !isFormValid || pin.length !== 4}
          className="w-full rounded-xl bg-gradient-to-r from-accent to-gold py-4 font-bold text-white shadow-lg shadow-accent/25 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
        >
          {isLoading ? "Processing..." : 
           (!amount || Number(amount) <= 0) ? "Enter Amount" :
           (!isFormValid) ? "Fill Account Details" :
           (pin.length !== 4) ? "Enter 4-Digit PIN" : 
           "Confirm Withdrawal"}
        </button>
        </form>

        {/* Pending Requests Section */}
        {pendingWithdraws.length > 0 && (
          <section className="mt-8 space-y-4">
            <h2 className="text-sm font-semibold text-text-dim flex items-center gap-2">
              <Clock size={16} /> Pending Requests
            </h2>
            <div className="space-y-3">
              {pendingWithdraws.map((req, i) => (
                <div key={req.id || i} className="flex items-center justify-between rounded-xl bg-bg-card p-4 border border-white/5 shadow-sm">
                  <div>
                    <p className="font-bold text-white">
                      {user?.currency_symbol || '₹'}{Number(req.amount).toLocaleString()}
                    </p>
                    <p className="text-xs text-text-dim uppercase mt-1">{req.method || 'Unknown'}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-xs font-bold text-gold uppercase tracking-wider bg-gold/10 px-2 py-1 rounded">Pending</span>
                    <button
                      type="button"
                      onClick={() => setCancelConfirmId(req.id)}
                      className="text-[10px] font-extrabold text-red-500 border border-red-500/20 bg-red-500/5 px-2 py-1 rounded-md hover:bg-red-500/10 transition-colors"
                    >
                      CANCEL
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>

      {/* Custom Cancel Confirmation Modal */}
      {cancelConfirmId && (
        <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm rounded-2xl border border-red-500/30 bg-bg-card p-6 text-center shadow-[0_0_30px_rgba(239,68,68,0.15)]">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-red-500/10">
              <AlertTriangle size={28} className="text-red-500" />
            </div>
            <h3 className="mb-2 text-lg font-bold text-white">Cancel Withdrawal?</h3>
            <p className="mb-6 text-sm text-text-dim">
              Are you sure you want to cancel this request? The amount will be instantly refunded to your wallet.
            </p>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setCancelConfirmId(null)}
                className="flex-1 rounded-xl bg-white/5 py-3 font-semibold text-white transition-colors hover:bg-white/10"
              >
                No, Keep it
              </button>
              <button
                type="button"
                onClick={executeCancel}
                className="flex-1 rounded-xl bg-red-500 py-3 font-bold text-white shadow-lg shadow-red-500/25 transition-transform hover:scale-[1.02] active:scale-95"
              >
                Yes, Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
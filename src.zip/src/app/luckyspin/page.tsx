"use client";

import { useEffect, useRef, useState } from "react";
import { useAuth } from "@/context/AuthContext";

const rewards = [
  { text: "JACKPOT", color: "#FFD700", coins: 10000 },
  { text: "5 Rupee", color: "#00ccff", coins: 5 },
  { text: "50 Rupee", color: "#ff9900", coins: 50 },
  { text: "3 Rupee", color: "#ff0055", coins: 3 },
  { text: "7 Rupee", color: "#ff0000", coins: 7 },
  { text: "10 Rupee", color: "#00ff88", coins: 10 },
  { text: "Bad Luck", color: "#1a1a1a", coins: 0 },
  { text: "20 Rupee", color: "#aa00ff", coins: 20 },
];

export default function LuckySpinPage() {
  const { token, refreshUser } = useAuth();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const [isSpinning, setIsSpinning] = useState(false);
  const [spinUsed, setSpinUsed] = useState(false);
  const [resultMsg, setResultMsg] = useState("LUCKY SPIN");
  const [currentRotation, setCurrentRotation] = useState(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Setup Canvas Properties
    const size = 320;
    const dpr = window.devicePixelRatio || 2;
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    ctx.scale(dpr, dpr);

    const centerX = size / 2, centerY = size / 2, radius = size / 2;
    const sliceAngle = (2 * Math.PI) / rewards.length;

    // Draw Wheel
    ctx.clearRect(0, 0, size, size);
    rewards.forEach((reward, i) => {
      const angle = i * sliceAngle;
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, angle, angle + sliceAngle);
      ctx.fillStyle = reward.color;
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,0.4)";
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(angle + sliceAngle / 2);
      ctx.textAlign = "right";
      ctx.fillStyle = "#fff";
      ctx.font = "bold 18px Arial";
      ctx.shadowBlur = 4;
      ctx.shadowColor = "#000";
      ctx.fillText(reward.text, radius - 25, 6);
      ctx.restore();
    });

    // Check Status
    const checkStatus = async () => {
      if (!token) return;
      try {
        const res = await fetch("/api/v1/luckywheel/status", {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();
        if (data.success && data.limit_reached) {
          setSpinUsed(true);
          setResultMsg("TODAY'S LIMIT REACHED");
        }
      } catch (e) {
        console.error("Failed to load wheel status");
      }
    };
    
    checkStatus();

    return () => {
      if (audioCtxRef.current && audioCtxRef.current.state !== "closed") {
        audioCtxRef.current.close().catch(() => {});
      }
    };
  }, [token]);

  const playTick = () => {
    if (!audioCtxRef.current) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        audioCtxRef.current = new AudioContextClass();
      }
    }
    const audioCtx = audioCtxRef.current;
    if (!audioCtx) return;
    if (audioCtx.state === "suspended") audioCtx.resume();

    const osc = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    osc.frequency.value = 580;
    g.gain.setValueAtTime(0.06, audioCtx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.04);
    osc.connect(g);
    g.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.04);
  };

  const spin = async () => {
    if (isSpinning || spinUsed || !token) return;
    setIsSpinning(true);
    setResultMsg("WISHING LUCK...");

    try {
      const res = await fetch("/api/v1/luckywheel/spin", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        credentials: "include"
      });
      const data = await res.json();

      if (data.success) {
        const { prizeIndex, amount } = data;

        // Calculate rotation securely based on the backend's prizeIndex
        const degPerSlice = 360 / rewards.length;
        const targetRotation = 270 - prizeIndex * degPerSlice - degPerSlice / 2;
        const currentMod = currentRotation % 360;
        const distance = (targetRotation - currentMod + 360) % 360;

        setCurrentRotation((prev) => prev + 360 * 15 + distance);

        // Play tick sound exponentially over the spin duration
        for (let i = 0; i < 80; i++) {
          setTimeout(() => { playTick(); }, 6000 * Math.pow(i / 80, 2.3));
        }

        setTimeout(async () => {
          setIsSpinning(false);
          setSpinUsed(true);

          if (amount > 0) {
            setResultMsg(`WIN: ${rewards[prizeIndex].text}! 🎉`);
            if (refreshUser) await refreshUser();
          } else {
            setResultMsg(`Oops! Bad Luck 💀`);
          }
        }, 6000);
      } else {
        setIsSpinning(false);
        setResultMsg(data.message || "SPIN FAILED");
      }
    } catch (e) {
      setIsSpinning(false);
      setResultMsg("ERROR CONNECTING TO SERVER");
    }
  };

  return (
    <div className="flex flex-col items-center justify-center w-full py-10 relative overflow-hidden bg-bg-dark text-white rounded-xl">
      {/* Wheel Architecture */}
      <div className="relative flex flex-col items-center mt-6">
        <div className="absolute bottom-[-60px] w-[100px] h-[140px] bg-gradient-to-r from-red-900 via-red-700 to-red-900 z-0 border-t-[5px] border-gold" style={{ clipPath: "polygon(25% 0%, 75% 0%, 100% 100%, 0% 100%)" }}></div>
        <div className="absolute bottom-[-80px] w-[220px] h-[30px] bg-red-950 rounded-full z-[2] shadow-[0_15px_30px_rgba(0,0,0,0.9)]"></div>

        <div className="relative w-[340px] h-[340px] z-[3] p-2.5 bg-gradient-to-tr from-[#bf953f] via-[#fcf6ba] to-[#b38728] rounded-full shadow-[0_0_50px_rgba(255,0,85,0.6)]">
          <div className="absolute inset-0 rounded-full z-[4] border-[10px] border-dotted border-gold animate-pulse pointer-events-none opacity-50"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-full w-[40px] h-[60px] bg-white z-[100] border-2 border-black drop-shadow-[0_0_10px_rgba(0,0,0,0.5)]" style={{ clipPath: "polygon(50% 100%, 0% 0%, 100% 0%)" }}></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[65px] h-[65px] bg-[radial-gradient(circle,#fff,gold,#b8860b)] rounded-full z-[101] border-[4px] border-[#222] shadow-[0_0_20px_gold]"></div>

          <canvas
            ref={canvasRef}
            className="w-[320px] h-[320px] rounded-full transition-transform duration-[6000ms] ease-[cubic-bezier(0.1,0,0.1,1)]"
            style={{ transform: `rotate(${currentRotation}deg)` }}
          ></canvas>
        </div>
      </div>

      {/* Action Controls */}
      <div className="text-center mt-24 z-10 flex flex-col items-center">
        <p className="mb-5 text-2xl md:text-3xl text-gold font-black h-[40px] drop-shadow-[0_0_15px_rgba(255,0,0,0.8)] uppercase">
          {resultMsg}
        </p>
        <button
          onClick={spin}
          disabled={isSpinning || spinUsed || !token}
          className="bg-gradient-to-b from-gold to-amber-700 text-black px-10 md:px-14 py-4 text-xl md:text-2xl border-none rounded-full cursor-pointer font-black shadow-[0_6px_0_#7a5a0d] uppercase mb-6 transition-all active:translate-y-[3px] active:shadow-[0_3px_0_#7a5a0d] disabled:bg-gray-700 disabled:from-gray-700 disabled:to-gray-800 disabled:text-gray-400 disabled:shadow-none disabled:cursor-not-allowed"
        >
          {!token ? "LOGIN TO SPIN" : spinUsed ? "SPIN USED" : isSpinning ? "SPINNING..." : "SPIN NOW"}
        </button>
      </div>
    </div>
  );
}
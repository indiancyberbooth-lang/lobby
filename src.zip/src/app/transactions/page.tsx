"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { Search, Wallet, Landmark, ArrowUpRight, ArrowDownLeft, AlertTriangle } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";

interface Transaction {
  id: string | number;
  type: "deposit" | "withdraw" | "transfer_sent" | "transfer_received";
  amount: number;
  status: "pending" | "approved" | "rejected" | "success" | "failed";
  utr?: string;
  ref_number?: string;
  payment_method?: string;
  created_at: string;
}

export default function TransactionsPage() {
  const { token, user } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [cancelConfirmId, setCancelConfirmId] = useState<string | number | null>(null);
  
  // Filter States
  const [activeTab, setActiveTab] = useState<"all" | "deposit" | "withdraw">("all");
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const res = await fetch(`/api/v1/history`, {
          credentials: "include"
        });
        const data = await res.json().catch(() => ({}));
        
        if (res.ok && (data.success || data.status === "success")) {
          setTransactions(data.transactions || []);
        }
      } catch (error) {
        console.error("Failed to fetch transactions:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTransactions();
  }, [token]);

  // Derived state for filtering transactions
  const filteredTransactions = transactions.filter((tx) => {
    // Tab Filter
    if (activeTab === "deposit") {
      if (tx.type !== "deposit" && tx.type !== "transfer_received") return false;
    }
    if (activeTab === "withdraw") {
      if (tx.type !== "withdraw" && tx.type !== "transfer_sent") return false;
    }

    // Search Filter (UTR or Ref Number)
    const q = searchQuery.toLowerCase();
    if (q) {
      const matchUtr = tx.utr?.toLowerCase().includes(q) || false;
      const matchRef = tx.ref_number?.toLowerCase().includes(q) || false;
      if (!matchUtr && !matchRef) return false;
    }

    return true;
  });

  const getTransactionConfig = (type: string) => {
    switch (type) {
      case "deposit":
        return { icon: Wallet, title: "DEPOSIT", isIncoming: true };
      case "withdraw":
        return { icon: Landmark, title: "WITHDRAWAL", isIncoming: false };
      case "transfer_received":
        return { icon: ArrowDownLeft, title: "RECEIVED", isIncoming: true };
      case "transfer_sent":
        return { icon: ArrowUpRight, title: "TRANSFERRED", isIncoming: false };
      default:
        return { icon: Wallet, title: type.toUpperCase(), isIncoming: true };
    }
  };

  const getStatusColor = (status: string) => {
    const s = status.toLowerCase();
    if (s === "pending") return "text-gold";
    if (s === "approved" || s === "success") return "text-green-500";
    if (s === "rejected" || s === "failed") return "text-red-500";
    return "text-white";
  };

  const executeCancel = async () => {
    if (!cancelConfirmId) return;
    try {
      const res = await fetch(`/api/v1/finance/withdraw/cancel`, {
        method: 'POST',
        credentials: "include",
        headers: { 
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ transaction_id: cancelConfirmId })
      });
      if (res.ok) {
        // Re-fetch transactions to update UI
        const fetchRes = await fetch(`/api/v1/history`, {
          credentials: "include"
        });
        const data = await fetchRes.json().catch(() => ({}));
        if (fetchRes.ok) setTransactions(data.transactions || []);
      } else {
        const errData = await res.json().catch(() => ({}));
        alert(errData.message || "Failed to cancel.");
      }
    } catch(err) { alert("Network error."); }
    setCancelConfirmId(null);
  };

  return (
    <div className="pb-10 pt-1">
      <PageHeader title="Transaction Records" showBackButton={true} />
      
      <div className="px-4">
        
        {/* Top Tab Switcher */}
        <div className="flex w-full rounded-full bg-bg-dark p-1 border border-white/10 shadow-inner mb-5">
          <button 
            onClick={() => setActiveTab("all")}
            className={`flex-1 rounded-full py-2.5 text-center text-sm font-bold transition-all ${activeTab === "all" ? "bg-white/10 text-white shadow-sm border border-white/5" : "text-text-dim hover:text-white"}`}
          >
            ALL
          </button>
          <button 
            onClick={() => setActiveTab("deposit")}
            className={`flex-1 rounded-full py-2.5 text-center text-sm font-bold transition-all ${activeTab === "deposit" ? "bg-green-500/20 text-green-500 shadow-sm border border-green-500/20" : "text-text-dim hover:text-white"}`}
          >
            DEPOSITS
          </button>
          <button 
            onClick={() => setActiveTab("withdraw")}
            className={`flex-1 rounded-full py-2.5 text-center text-sm font-bold transition-all ${activeTab === "withdraw" ? "bg-red-500/20 text-red-500 shadow-sm border border-red-500/20" : "text-text-dim hover:text-white"}`}
          >
            WITHDRAWALS
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative mb-5">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-text-dim">
            <Search size={18} />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search UTR or Reference No..."
            className="w-full rounded-xl border border-white/10 bg-bg-card py-3.5 pl-11 pr-4 text-sm font-semibold text-white placeholder:font-normal placeholder:text-text-dim focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold shadow-inner"
          />
        </div>

        {/* Transactions List */}
        <div className="space-y-3">
          {isLoading ? (
            <div className="text-center py-10 text-text-dim text-sm font-semibold">Loading transactions...</div>
          ) : filteredTransactions.length === 0 ? (
            <div className="text-center py-10 text-text-dim text-sm bg-bg-dark rounded-xl border border-white/5">No transactions found.</div>
          ) : (
            filteredTransactions.map((tx, index) => {
              const config = getTransactionConfig(tx.type);
              const Icon = config.icon;
              const statusColor = getStatusColor(tx.status);
              const refText = tx.utr || tx.ref_number || "No Ref";
              
              return (
                <div key={tx.id || index} className="flex items-center justify-between rounded-xl bg-bg-card p-4 border border-white/5 hover:bg-white/5 transition-colors cursor-pointer shadow-sm">
                  <div className="flex items-center gap-3">
                    {/* Icon Badge */}
                    <div className={`flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg ${config.isIncoming ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
                      <Icon size={18} />
                    </div>
                    
                    {/* Title & Info */}
                    <div className="overflow-hidden">
                      <div className="flex items-center gap-2">
                        <p className="font-bold text-sm text-white tracking-wide">{config.title}</p>
                        {tx.payment_method && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-white/5 text-text-dim border border-white/5 uppercase">
                            {tx.payment_method}
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-text-dim mt-0.5">
                        {new Date(tx.created_at).toLocaleString(undefined, {
                          year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
                        })}
                      </p>
                      <p className="text-[9px] font-mono text-text-dim mt-1.5 truncate max-w-[120px] opacity-70">
                        REF: {refText}
                      </p>
                    </div>
                  </div>
                  
                  {/* Amount & Status */}
                  <div className="text-right flex-shrink-0 flex flex-col items-end">
                    <p className="font-black text-[15px] text-white">
                      {config.isIncoming ? '+' : '-'}{user?.currency_symbol || '₹'}{tx.amount.toLocaleString()}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      {tx.type === "withdraw" && tx.status.toLowerCase() === "pending" && (
                        <button onClick={(e) => { e.stopPropagation(); setCancelConfirmId(tx.id); }} className="text-[10px] font-extrabold text-red-500 border border-red-500/20 bg-red-500/5 px-2 py-1 rounded-md hover:bg-red-500/10 transition-colors">
                          CANCEL
                        </button>
                      )}
                      <p className={`text-[10px] font-bold uppercase tracking-wider ${statusColor}`}>{tx.status}</p>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Custom Cancel Confirmation Modal */}
      {cancelConfirmId && (
        <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm rounded-2xl border border-red-500/30 bg-bg-card p-6 text-center shadow-[0_0_30px_rgba(239,68,68,0.15)]">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-red-500/10">
              <AlertTriangle size={28} className="text-red-500" />
            </div>
            <h3 className="mb-2 text-lg font-bold text-white">Cancel Withdrawal?</h3>
            <p className="mb-6 text-sm text-text-dim">
              Are you sure you want to cancel this request? The amount will be instantly refunded to your wallet.
            </p>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setCancelConfirmId(null)}
                className="flex-1 rounded-xl bg-white/5 py-3 font-semibold text-white transition-colors hover:bg-white/10"
              >
                No, Keep it
              </button>
              <button
                type="button"
                onClick={executeCancel}
                className="flex-1 rounded-xl bg-red-500 py-3 font-bold text-white shadow-lg shadow-red-500/25 transition-transform hover:scale-[1.02] active:scale-95"
              >
                Yes, Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
import type { Metadata, Viewport } from "next";
import { Poppins } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/context/AuthContext";
import AppShell from "@/components/AppShell";
import { headers } from "next/headers";
import { BrandProvider } from "@/context/BrandContext";

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
});

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  userScalable: false,
  interactiveWidget: "resizes-content",
};

export async function generateMetadata(): Promise<Metadata> {
  const headersList = await headers();
  const domain = headersList.get('x-site-domain') || 'localhost';
  
  let title = 'Casino';
  let favicon = null;
  
  try {
    const BACKEND_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3000';
    const res = await fetch(`${BACKEND_URL}/api/v1/utils/theme?domain=${domain}`, {
      next: { revalidate: 60 }
    });
    if (res.ok) {
      const data = await res.json();
      if (data.success) {
        if (data.brand_name) title = data.brand_name;
        if (data.favicon_url) favicon = data.favicon_url;
        else if (data.logo_url) favicon = data.logo_url; // fallback to logo if favicon is missing
      }
    }
  } catch (err) {
    console.error("Metadata fetch failed:", err);
  }

  const metadata: Metadata = { title };
  
  if (favicon) {
    metadata.icons = { icon: favicon };
  }
  
  return metadata;
}

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const headersList = await headers();
  const domain = headersList.get('x-site-domain') || 'localhost';
  
  let themeColor = '#fbbf24'; // Default gold
  let brandName = '';
  let logoUrl = null;
  let faviconUrl = null;
  
  try {
    // Fetch theme from the backend (running on port 3000)
    const BACKEND_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3000';
    const res = await fetch(`${BACKEND_URL}/api/v1/utils/theme?domain=${domain}`, {
      next: { revalidate: 60 } // Cache for 60 seconds for extreme speed
    });
    if (res.ok) {
      const data = await res.json();
      if (data.success) {
        themeColor = data.theme_color || themeColor;
        brandName = data.brand_name || brandName;
        logoUrl = data.logo_url || logoUrl;
        faviconUrl = data.favicon_url || faviconUrl;
      }
    }
  } catch (err) {
    console.error("Theme fetch failed:", err);
  }

  return (
    <html lang="en">
      <head>
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
          crossOrigin="anonymous"
          referrerPolicy="no-referrer"
        />
      </head>
      <body 
        className={`${poppins.className} bg-bg-dark text-white antialiased no-scrollbar overflow-x-hidden w-full`}
        style={{ '--color-gold': themeColor } as React.CSSProperties}
      >
        <BrandProvider brandName={brandName} logoUrl={logoUrl} faviconUrl={faviconUrl}>
          <AuthProvider>
            <AppShell>{children}</AppShell>
          </AuthProvider>
        </BrandProvider>
      </body>
    </html>
  );
}
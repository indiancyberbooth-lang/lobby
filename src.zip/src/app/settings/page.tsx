"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { PageHeader } from "@/components/PageHeader";
import { Lock, Shield, Volume2, Sparkles, ChevronRight, ArrowLeft, LogOut } from "lucide-react";

type ViewState = "main" | "password" | "pin";

export default function SettingsPage() {
  const router = useRouter();
  const [currentView, setCurrentView] = useState<ViewState>("main");
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [vfxEnabled, setVfxEnabled] = useState(true);

  // Form States
  const [oldPass, setOldPass] = useState("");
  const [newPass, setNewPass] = useState("");
  const [confPass, setConfPass] = useState("");
  const [pin, setPin] = useState("");
  const [confPin, setConfPin] = useState("");

  // UI Feedback States
  const [message, setMessage] = useState("");
  const [isError, setIsError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleViewChange = (view: ViewState) => {
    setCurrentView(view);
    setMessage("");
    setIsError(false);
    setOldPass("");
    setNewPass("");
    setConfPass("");
    setPin("");
    setConfPin("");
  };

  const handlePasswordUpdate = async () => {
    if (!oldPass || !newPass || !confPass) {
      setIsError(true);
      setMessage("Please fill all password fields.");
      return;
    }
    if (newPass !== confPass) {
      setIsError(true);
      setMessage("New passwords do not match.");
      return;
    }

    setIsLoading(true);
    setMessage("");
    setIsError(false);

    try {
      const res = await fetch(`/api/v1/users/update-password`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ old_pass: oldPass, new_pass: newPass })
      });
      const data = await res.json().catch(() => ({}));

      if (res.ok && (data.success || data.status === 'success')) {
        setIsError(false);
        setMessage(data.message || "Password updated successfully.");
        setOldPass("");
        setNewPass("");
        setConfPass("");
      } else {
        setIsError(true);
        setMessage(data.message || "Failed to update password.");
      }
    } catch (err) {
      setIsError(true);
      setMessage("A network error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  const handlePinUpdate = async () => {
    if (pin.length !== 4 || !/^\d{4}$/.test(pin)) {
      setIsError(true);
      setMessage("PIN must be exactly 4 digits.");
      return;
    }
    if (pin !== confPin) {
      setIsError(true);
      setMessage("PINs do not match.");
      return;
    }

    setIsLoading(true);
    setMessage("");
    setIsError(false);

    try {
      const res = await fetch(`/api/v1/users/update-pin`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ new_pin: pin })
      });
      const data = await res.json().catch(() => ({}));

      if (res.ok && (data.success || data.status === 'success')) {
        setIsError(false);
        setMessage(data.message || "PIN updated successfully.");
        setPin("");
        setConfPin("");
      } else {
        setIsError(true);
        setMessage(data.message || "Failed to update PIN.");
      }
    } catch (err) {
      setIsError(true);
      setMessage("A network error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/v1/users/logout", {
        method: "POST",
        credentials: "include",
      });
    } catch (err) {
      console.error("Logout request failed", err);
    } finally {
      if (typeof window !== 'undefined') {
        // Clean up any residual non-secure items just in case
        localStorage.removeItem('username');
      }
      router.push('/login');
    }
  };

  if (currentView === "password") {
    return (
      <div className="pb-10 pt-4">
        <header className="relative mb-6 flex h-[60px] items-center justify-center bg-bg-card border-b border-white/5">
          <button onClick={() => handleViewChange("main")} className="absolute left-4 top-1/2 -translate-y-1/2 text-text-dim hover:text-white">
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-lg font-semibold">Change Password</h1>
        </header>
        <div className="px-4 space-y-4">
          {message && (
            <div className={`p-3 rounded-xl text-xs font-bold text-center uppercase border ${isError ? 'bg-red-500/10 border-red-500/20 text-red-500' : 'bg-green-500/10 border-green-500/20 text-green-500'}`}>
              {message}
            </div>
          )}
          <input type="password" value={oldPass} onChange={(e) => setOldPass(e.target.value)} placeholder="Current Password" className="w-full rounded-xl border border-white/10 bg-bg-card p-4 text-white placeholder:text-text-dim focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold" />
          <input type="password" value={newPass} onChange={(e) => setNewPass(e.target.value)} placeholder="New Password" className="w-full rounded-xl border border-white/10 bg-bg-card p-4 text-white placeholder:text-text-dim focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold" />
          <input type="password" value={confPass} onChange={(e) => setConfPass(e.target.value)} placeholder="Confirm New Password" className="w-full rounded-xl border border-white/10 bg-bg-card p-4 text-white placeholder:text-text-dim focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold" />
          <button 
            onClick={handlePasswordUpdate}
            disabled={isLoading}
            className="mt-4 w-full rounded-xl bg-gradient-to-r from-accent to-gold py-4 font-bold text-white shadow-lg transition-transform active:scale-95 disabled:opacity-70"
          >
            {isLoading ? "Updating..." : "Update Password"}
          </button>
        </div>
      </div>
    );
  }

  if (currentView === "pin") {
    return (
      <div className="pb-10 pt-4">
        <header className="relative mb-6 flex h-[60px] items-center justify-center bg-bg-card border-b border-white/5">
          <button onClick={() => handleViewChange("main")} className="absolute left-4 top-1/2 -translate-y-1/2 text-text-dim hover:text-white">
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-lg font-semibold">Security PIN</h1>
        </header>
        <div className="px-4 space-y-4">
          <p className="text-sm text-text-dim mb-4">Set a 4-digit PIN to secure your withdrawals and sensitive actions.</p>
          {message && (
            <div className={`p-3 rounded-xl text-xs font-bold text-center uppercase border ${isError ? 'bg-red-500/10 border-red-500/20 text-red-500' : 'bg-green-500/10 border-green-500/20 text-green-500'}`}>
              {message}
            </div>
          )}
          <input type="password" value={pin} onChange={(e) => setPin(e.target.value)} maxLength={4} placeholder="Enter 4-Digit PIN" className="w-full rounded-xl border border-white/10 bg-bg-card p-4 text-center text-2xl tracking-[1em] text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold" />
          <input type="password" value={confPin} onChange={(e) => setConfPin(e.target.value)} maxLength={4} placeholder="Confirm 4-Digit PIN" className="w-full rounded-xl border border-white/10 bg-bg-card p-4 text-center text-2xl tracking-[1em] text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold" />
          <button 
            onClick={handlePinUpdate}
            disabled={isLoading}
            className="mt-4 w-full rounded-xl bg-gradient-to-r from-accent to-gold py-4 font-bold text-white shadow-lg transition-transform active:scale-95 disabled:opacity-70"
          >
            {isLoading ? "Saving..." : "Save PIN"}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-10 pt-4">
      <PageHeader title="Account Settings" showBackButton={true} />

      <div className="space-y-6 px-4">
        {/* Security Options */}
        <section>
          <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-text-dim">Security</h2>
          <div className="overflow-hidden rounded-xl border border-white/10 bg-bg-card">
            <button 
              onClick={() => handleViewChange("password")}
              className="flex w-full items-center justify-between border-b border-white/5 p-4 transition-colors hover:bg-white/5"
            >
              <div className="flex items-center gap-3 text-white">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/5 text-text-dim">
                  <Lock size={16} />
                </div>
                <span className="font-medium text-sm">Change Login Password</span>
              </div>
              <ChevronRight size={18} className="text-text-dim" />
            </button>
            
            <button 
              onClick={() => handleViewChange("pin")}
              className="flex w-full items-center justify-between p-4 transition-colors hover:bg-white/5"
            >
              <div className="flex items-center gap-3 text-white">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/5 text-text-dim">
                  <Shield size={16} />
                </div>
                <span className="font-medium text-sm">Withdrawal PIN</span>
              </div>
              <ChevronRight size={18} className="text-text-dim" />
            </button>
          </div>
        </section>

        {/* Preferences */}
        <section>
          <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-text-dim">Preferences</h2>
          <div className="overflow-hidden rounded-xl border border-white/10 bg-bg-card">
            <div className="flex items-center justify-between border-b border-white/5 p-4">
              <div className="flex items-center gap-3 text-white">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/5 text-text-dim"><Volume2 size={16} /></div>
                <div><p className="font-medium text-sm">Sound Effects</p><p className="text-[10px] text-text-dim">Lobby interactions and alerts</p></div>
              </div>
              <button onClick={() => setSoundEnabled(!soundEnabled)} className={`relative h-6 w-11 rounded-full transition-colors ${soundEnabled ? 'bg-gold' : 'bg-bg-dark border border-white/10'}`}>
                <div className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-transform ${soundEnabled ? 'left-6' : 'left-1'}`}></div>
              </button>
            </div>

            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3 text-white">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/5 text-text-dim"><Sparkles size={16} /></div>
                <div><p className="font-medium text-sm">VFX Animations</p><p className="text-[10px] text-text-dim">Premium visual effects & particles</p></div>
              </div>
              <button onClick={() => setVfxEnabled(!vfxEnabled)} className={`relative h-6 w-11 rounded-full transition-colors ${vfxEnabled ? 'bg-gold' : 'bg-bg-dark border border-white/10'}`}>
                <div className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-transform ${vfxEnabled ? 'left-6' : 'left-1'}`}></div>
              </button>
            </div>
          </div>
        </section>

        <section>
          <button onClick={handleLogout} className="flex w-full items-center justify-center gap-2 rounded-xl border border-red-500/20 bg-red-500/10 p-4 font-bold text-red-500 transition-colors hover:bg-red-500/20 active:scale-95">
            <LogOut size={20} />
            Logout Session
          </button>
        </section>
      </div>
    </div>
  );
}

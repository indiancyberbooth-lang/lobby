"use client";

import { ElementType } from "react";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils"; // We'll create this utility file next

type TransactionStatus =
  | "win"
  | "loss"
  | "pending"
  | "approved"
  | "rejected";

interface TransactionListProps {
  icon: ElementType;
  title: string;
  subtext: string;
  date: string;
  amount: number;
  status: TransactionStatus;
}

const statusStyles: Record<TransactionStatus, string> = {
  win: "text-green-500",
  approved: "text-green-500",
  loss: "text-red-500",
  rejected: "text-red-500",
  pending: "text-gold",
};

export const TransactionList = ({
  icon: Icon,
  title,
  subtext,
  date,
  amount,
  status,
}: TransactionListProps) => {
  const { user } = useAuth();
  const isPositive = status === "win" || status === "approved";

  return (
    <div className="flex items-center justify-between rounded-lg border border-white/5 bg-bg-card p-4">
      <div className="flex items-center gap-4">
        <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-bg-dark">
          <Icon className="h-5 w-5 text-text-dim" />
        </div>
        <div>
          <p className="font-semibold text-white">{title}</p>
          <p className="text-xs text-text-dim">{subtext}</p>
        </div>
      </div>
      <div className="text-right">
        <p
          className={`text-lg font-bold ${
            isPositive ? "text-green-500" : "text-white"
          }`}
        >
        {isPositive ? "+" : ""}{user?.currency_symbol || '₹'}{amount.toLocaleString()}
        </p>
        <p className={`text-xs font-semibold capitalize ${statusStyles[status]}`}>
          {status}
        </p>
      </div>
    </div>
  );
};
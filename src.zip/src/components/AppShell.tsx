"use client";

import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import Link from "next/link";
import { Home, Landmark, User, Gamepad2, Dice5, History, Users, AlertCircle } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useBrand } from "@/context/BrandContext";

const navItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/bets", label: "Bets", icon: Gamepad2 },
  { href: "/deposit", label: "Funds", icon: Landmark },
  { href: "/refer", label: "Refer", icon: Users },
  { href: "/profile", label: "Profile", icon: User },
];

export default function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { user, token, isAuthenticated, isLoading } = useAuth();
  const { brandName, logoUrl } = useBrand();
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const handleProtectedClick = (e: React.MouseEvent<HTMLAnchorElement>, path: string) => {
    const protectedPaths = ['/profile', '/bets', '/refer', '/deposit', '/withdraw', '/transfer', '/settings'];
    
    if (protectedPaths.includes(path) && !isAuthenticated) {
      e.preventDefault();
      setToastMessage("LOGIN REQUIRED");
      setTimeout(() => setToastMessage(null), 500);
    }
  };

  const isAuthRoute = ["/login", "/register", "/verify"].includes(pathname);
  if (isAuthRoute) {
    return <>{children}</>;
  }

  return (
    <>
      <div className="relative flex min-h-screen">
        {/* Left Sidebar (Desktop) */}
        <aside className="hidden w-20 bg-bg-card p-4 pt-24 text-center md:block fixed left-0 top-0 h-screen z-40 border-r border-white/5">
          <nav className="flex flex-col items-center space-y-6">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                replace
                className={`flex flex-col items-center space-y-2 text-sm transition-colors ${
                  pathname === item.href
                    ? "text-gold"
                    : "text-text-dim hover:text-gold"
                }`}
              >
                <item.icon size={24} />
                <span>{item.label}</span>
              </Link>
            ))}
          </nav>
        </aside>

        {/* Main Content Area */}
        <div className="flex-1 md:ml-20 min-w-0">
          {/* Fixed Header */}
          <header className="fixed top-0 left-0 right-0 z-50 flex h-[60px] items-center justify-between border-b border-b-white/10 bg-bg-card/80 px-4 backdrop-blur-lg md:left-20">
            <div className="flex items-center">
              {/* THIS PART IS STATIC - Safe from re-renders and blinking */}
              <Link href="/" className="text-xl font-bold italic text-gold flex items-center gap-2">
                {logoUrl ? (
                  <img src={logoUrl} alt={brandName} className="h-10 md:h-12 w-auto object-contain transition-all" />
                ) : (
                  brandName
                )}
              </Link>
            </div>

            <div className="flex items-center min-w-[150px] justify-end space-x-2">
              {/* ONLY THE ACTIONS ARE CONDITIONAL */}
              {(!isMounted || isLoading) ? (
                <div className="h-9 w-32 animate-pulse rounded-full bg-white/5" />
              ) : (token || user) ? (
                <Link href="/profile" className="flex items-center gap-3 transition-opacity hover:opacity-80">
                  <div className="flex flex-col items-end leading-tight">
                    <span className="text-sm font-black text-gold tracking-wide">
                      {user?.currency_symbol || "₹"} {Number(user?.balance || 0).toFixed(2)}
                    </span>
                    <span className="text-[10px] font-medium text-text-dim/80 truncate max-w-[100px]">
                      @{user?.username || '...'}
                    </span>
                  </div>
                  <div className="h-9 w-9 rounded-full border border-white/10 bg-white/5 flex items-center justify-center text-gold">
                    <User size={16} />
                  </div>
                </Link>
              ) : (
                <>
                  <Link href="/login" className="rounded-md px-4 py-1.5 text-sm font-semibold text-white/80 hover:bg-white/10">Login</Link>
                  <Link href="/register" className="rounded-md bg-gold px-4 py-1.5 text-sm font-semibold text-black hover:bg-[#f1c40f]">Register</Link>
                </>
              )}
            </div>
          </header>

          {/* Page Content */}
          <main className="pt-[76px] pb-[86px] md:pb-4 w-full overflow-x-hidden">{children}</main>
        </div>
      </div>

      {/* Bottom Navigation (Mobile) */}
      <footer className="fixed bottom-0 left-0 right-0 z-50 flex h-[70px] items-center justify-around border-t border-t-white/10 bg-bg-card/80 backdrop-blur-lg md:hidden">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={(e) => handleProtectedClick(e, item.href)}
              replace
              className={`flex flex-col items-center transition-colors ${
                isActive ? "text-gold" : "text-text-dim hover:text-gold"
              }`}
            >
              <div
                className={`rounded-full p-1.5 transition-shadow ${
                  isActive ? "shadow-[0_0_15px_rgba(251,191,36,0.7)]" : ""
                }`}
              >
                <item.icon size={20} />
              </div>
              <span className={`mt-1 text-[10px] ${isActive ? "font-bold" : ""}`}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </footer>

      {toastMessage && (
        <div className="fixed top-10 left-1/2 -translate-x-1/2 z-[99999] animate-in fade-in slide-in-from-top-5 duration-300">
          <div className="flex items-center gap-3 rounded-full border border-gold/50 bg-bg-card/95 px-6 py-3 shadow-[0_0_20px_rgba(251,191,36,0.3)] backdrop-blur-md">
            <AlertCircle className="text-gold" size={20} />
            <span className="text-sm font-bold tracking-wide text-white uppercase">
              {toastMessage}
            </span>
          </div>
        </div>
      )}
    </>
  );
}
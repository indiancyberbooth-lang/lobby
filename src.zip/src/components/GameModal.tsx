"use client";

import { useEffect } from "react";

interface GameModalProps {
  gameUrl: string;
  onClose: () => void;
}

export default function GameModal({ gameUrl, onClose }: GameModalProps) {
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data === 'CLOSE_GAME') {
        onClose();
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-[100] bg-black overflow-hidden">
      <iframe
        src={gameUrl}
        title="Game Launch"
        className="h-full w-full border-none outline-none"
        allow="autoplay; fullscreen"
        allowFullScreen
      ></iframe>
    </div>
  );
}
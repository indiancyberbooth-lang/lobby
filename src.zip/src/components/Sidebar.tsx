"use client";

import { Flame, Trophy, Club, Gamepad2, Puzzle, Disc, ArrowRightLeft } from "lucide-react";

const categories = [
  { id: "live", name: "LIVE", icon: Flame, isComingSoon: false },
  { id: "sports", name: "SPORTSBOOK", icon: Trophy, isComingSoon: false },
  { id: "exchange", name: "EXCHANGE", icon: ArrowRightLeft, isComingSoon: true },
  { id: "casino", name: "CASINO", icon: Club, isComingSoon: false },
  { id: "multiplayer", name: "MULTI", icon: Puzzle, isComingSoon: true },
  { id: "slot", name: "SLOT", icon: Gamepad2, isComingSoon: false },
  { id: "lucky-spin", name: "LUCKY SPIN", icon: Disc, isComingSoon: false },
];

interface SidebarProps {
  activeCategory: string;
  onSelect: (id: string) => void;
}

export default function Sidebar({ activeCategory, onSelect }: SidebarProps) {
  return (
    <aside className="fixed left-0 md:left-20 top-[60px] bottom-[70px] md:bottom-0 w-[45px] min-w-[45px] max-w-[45px] flex-shrink-0 border-r border-white/5 bg-bg-card z-40 px-0 flex flex-col">
      <nav className="flex h-full flex-col items-center py-4 space-y-4">
        {categories.map((cat) => {
          const isActive = cat.id === activeCategory;
          return (
            <button
              key={cat.id}
              onClick={() => onSelect(cat.id)}
              className={`group relative flex w-full flex-col items-center justify-center py-2 transition-colors ${
                isActive ? "text-gold" : "text-text-dim hover:text-white"
              } ${cat.isComingSoon ? "opacity-50 cursor-not-allowed" : ""}`}
              disabled={cat.isComingSoon}
            >
              {isActive && (
                <div className="absolute left-0 top-0 h-full w-[3px] rounded-r-md bg-gold shadow-[0_0_10px_rgba(251,191,36,0.8)]" />
              )}
              {cat.icon && (
                <cat.icon size={18} className={isActive ? "drop-shadow-[0_0_5px_rgba(251,191,36,0.5)]" : ""} />
              )}
              <span className="mt-1 text-[6px] font-extrabold text-center leading-none w-full break-words px-0">
                {cat.name}
              </span>
            </button>
          );
        })}
      </nav>
    </aside>
  );
}
"use client";

import { ChevronLeft } from "lucide-react";
import { useRouter } from "next/navigation";

interface PageHeaderProps {
  title: string;
  showBackButton?: boolean;
}

export const PageHeader = ({ title, showBackButton = false }: PageHeaderProps) => {
  const router = useRouter();

  return (
    <header className="relative mb-6 flex h-[60px] items-center justify-center bg-bg-card">
      {showBackButton && (
        <button
          onClick={() => router.back()}
          className="absolute left-4 top-1/2 -translate-y-1/2 text-text-dim hover:text-white"
        >
          <ChevronLeft size={24} />
        </button>
      )}
      <h1 className="text-lg font-semibold">{title}</h1>
    </header>
  );
};
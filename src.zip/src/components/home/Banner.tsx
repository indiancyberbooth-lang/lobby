"use client";

import { useState, useEffect, TouchEvent } from "react";
import { useRouter } from "next/navigation";

interface BannerData {
  id: number;
  image_url: string;
  target_link?: string;
}

export default function Banner() {
  const [banners, setBanners] = useState<BannerData[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);
  const router = useRouter();

  // Fetch Banners from Backend
  useEffect(() => {
    const fetchBanners = async () => {
      try {
        const res = await fetch("/api/v1/banners/list", {
          credentials: "include",
        });
        const data = await res.json();
        if (data.success && data.banners && data.banners.length > 0) {
          setBanners(data.banners);
        } else {
          // Fallback if no banners are uploaded yet
          setBanners([
            { id: 0, image_url: "https://placehold.co/800x342/0a0a0f/fbbf24?text=Welcome+to+MAHAKAAL" }
          ]);
        }
      } catch (error) {
        console.error("Failed to fetch banners:", error);
      }
    };
    fetchBanners();
  }, []);

  // Auto-scroll logic
  useEffect(() => {
    if (banners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % banners.length);
    }, 3000); // 3-second interval

    return () => clearInterval(interval);
  }, [banners.length]);

  const handleBannerClick = (link?: string) => {
    if (link) {
      if (link.startsWith("http")) {
        window.open(link, "_blank"); // Open external links in new tab
      } else {
        router.push(link); // Internal routing (e.g., /sports)
      }
    }
  };

  const handleTouchStart = (e: TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe) {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % banners.length);
    } else if (isRightSwipe) {
      setCurrentIndex((prevIndex) => (prevIndex - 1 + banners.length) % banners.length);
    }

    // Reset touch coordinates
    setTouchStart(0);
    setTouchEnd(0);
  };

  if (banners.length === 0) return null;

  return (
    <section 
      className="relative aspect-[21/9] w-full overflow-hidden rounded-xl border border-white/10 shadow-lg shadow-black/50"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {banners.map((banner, index) => (
        <div 
          key={banner.id} 
          className={`absolute inset-0 transition-opacity duration-1000 ${index === currentIndex ? "opacity-100 z-10 pointer-events-auto" : "opacity-0 z-0 pointer-events-none"}`}
        >
          <img 
            src={banner.image_url} 
            alt={`Banner ${index + 1}`} 
            className="h-full w-full object-cover cursor-pointer" 
            onClick={() => handleBannerClick(banner.target_link)} 
          />
        </div>
      ))}
      
      {banners.length > 1 && (
        <div className="absolute bottom-2 left-1/2 flex -translate-x-1/2 gap-1.5 z-10">
          {banners.map((_, index) => (
            <div 
              key={index} 
              onClick={() => setCurrentIndex(index)}
              className={`h-1 w-4 rounded-full transition-colors duration-300 cursor-pointer ${index === currentIndex ? "bg-gold shadow-[0_0_5px_rgba(251,191,36,0.8)]" : "bg-white/30"}`} 
            />
          ))}
        </div>
      )}
    </section>
  );
}
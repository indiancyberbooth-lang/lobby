"use client";

import { useState, useEffect, useRef } from "react";
import { Lock } from "lucide-react";
import { useRouter } from "next/navigation";

interface Match {
  id: string;
  series?: string;
  team_a?: { name: string; score?: string; logo?: string; overs?: string };
  team_b?: { name: string; score?: string; logo?: string; overs?: string };
  odds?: { "1"?: number; X?: number; "2"?: number };
  isLive?: boolean;
  live_score?: any;
}

const usePrevious = <T,>(value: T): T | undefined => {
  const ref = useRef<T | undefined>(undefined);
  useEffect(() => {
    ref.current = value;
  });
  return ref.current;
};

function SportsCard({ match }: { match: Match }) {
  const [flash, setFlash] = useState<"1" | "X" | "2" | null>(null);
  const prevOdds = usePrevious(match.odds);
  const router = useRouter();

  useEffect(() => {
    if (prevOdds && match?.odds) {
      if (prevOdds["1"] !== match.odds["1"]) setFlash("1");
      else if (prevOdds["X"] !== match.odds["X"]) setFlash("X");
      else if (prevOdds["2"] !== match.odds["2"]) setFlash("2");

      const timer = setTimeout(() => setFlash(null), 500);
      return () => clearTimeout(timer);
    }
  }, [match?.odds, prevOdds]);

  const getFlashClass = (key: "1" | "X" | "2") => {
    if (flash !== key) return "";
    if (!prevOdds || !match?.odds) return "";
    const prev = prevOdds[key] || 0;
    const curr = match.odds[key] || 0;
    if (prev === curr) return "";
    return prev > curr ? "bg-red-500/40" : "bg-green-500/40";
  };

  const handleCardClick = () => {
    router.push(`/play/sportsbook?matchId=${match.id}`);
  };

  return (
    <div onClick={handleCardClick} className="bg-gradient-to-b from-[#1e1e2d] to-[#111118] border border-white/5 rounded-lg p-4 w-full cursor-pointer">
      {/* TOP ROW (Date & Live Dot) */}
      <div className="flex justify-between items-center">
        <span className="text-[#fbbf24] text-[11px] font-extrabold tracking-wide uppercase">
          LIVE MATCH
        </span>
        {match?.isLive && (
          <div className="w-2 h-2 bg-[#e11d48] rounded-full shadow-[0_0_8px_#e11d48] animate-pulse"></div>
        )}
      </div>

      {/* SECOND ROW (Series) */}
      <div className="text-[#7a6e8f] text-[11px] font-bold mt-1 mb-3 uppercase">
        {match?.series || "Unknown Series"}
      </div>

      {/* THIRD ROW (Teams & VS) */}
      <div className="flex justify-between items-center mb-4">
        <span className="text-white font-bold text-base w-2/5 text-left truncate">
          {match?.team_a?.name || "Team A"}
        </span>
        <span className="text-[#7a6e8f] text-[10px] w-1/5 text-center lowercase">
          vs
        </span>
        <span className="text-white font-bold text-base w-2/5 text-right truncate">
          {match?.team_b?.name || "Team B"}
        </span>
      </div>

      {/* BOTTOM ROW (Score & Odds) */}
      <div className="flex justify-between items-end w-full">
        {/* SCORE COLUMN (Left) */}
        <div className="flex flex-col items-center">
          <span className="text-[#7a6e8f] text-[8px] tracking-[1px] font-bold mb-0.5">SCORE</span>
          <span className="text-white text-[22px] font-black leading-none">
            {match?.team_a?.score || "0/0"}
          </span>
          <span className="text-[#888] text-[11px] font-semibold mt-1">
            {match?.team_a?.overs ? `(${match.team_a?.overs})` : "Yet to bat"}
          </span>
        </div>

        {/* ODDS COLUMN (Right) */}
        <div className="flex flex-col items-center">
          <div className="text-[#888] text-[10px] font-bold text-center w-full mb-1.5">1X2</div>
          <div className="flex gap-1.5">
            <button className={`w-[55px] h-[55px] bg-[#2d5a9e] rounded-md flex flex-col justify-center items-center shadow-md transition-colors ${getFlashClass("1")}`}>
              <span className="text-white/70 text-[10px] mb-0.5">1</span>
              <span className="text-white text-sm font-bold">{match?.odds?.["1"] ? match.odds["1"]?.toFixed(2) : "-"}</span>
            </button>
            <button className="w-[55px] h-[55px] bg-[#444] rounded-md flex justify-center items-center" disabled>
              <Lock size={14} className="text-white/40" />
            </button>
            <button className={`w-[55px] h-[55px] bg-[#2d5a9e] rounded-md flex flex-col justify-center items-center shadow-md transition-colors ${getFlashClass("2")}`}>
              <span className="text-white/70 text-[10px] mb-0.5">2</span>
              <span className="text-white text-sm font-bold">{match?.odds?.["2"] ? match.odds["2"]?.toFixed(2) : "-"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function SportsGrid() {
  const [matches, setMatches] = useState<Match[]>([]);

  useEffect(() => {
    const fetchMatches = async () => {
      try {
        const QUANTUM_BASE = process.env.NEXT_PUBLIC_QUANTUM_API_URL || "http://localhost:4000";
        const res = await fetch(`${QUANTUM_BASE}/api/v1/sports/cricket/matches`);
        if (res.ok) {
          const data = await res.json();
          setMatches(data.matches || data);
        }
      } catch (error) {
        console.error("Failed to fetch sports matches:", error);
      }
    };

    fetchMatches();
    const interval = setInterval(fetchMatches, 5000);
    return () => clearInterval(interval);
  }, []);

  if (matches.length === 0) return null;

  return (
    <section className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
    {matches.map((match, index) => <SportsCard key={match.id || index} match={match} />)}
    </section>
  );
}
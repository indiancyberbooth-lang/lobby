"use client";

import { useState, useEffect } from "react";
import { Play } from "lucide-react";

interface Game {
  id: string;
  name: string;
  provider: string;
  thumbnail: string;
  thumbnail_url?: string;
  category?: string;
  type?: string;
}

interface GameGridProps {
  category: string;
  onLaunchGame: (gameId: string) => void;
}

export default function GameGrid({ category, onLaunchGame }: GameGridProps) {
  const [games, setGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSub, setSelectedSub] = useState("All");

  const QUANTUM_BASE = process.env.NEXT_PUBLIC_QUANTUM_API_URL || "http://localhost:4000";
  const ASSET_BASE = process.env.NEXT_PUBLIC_ASSET_URL;
  const cleanAssetBase = ASSET_BASE ? ASSET_BASE.replace(/\/$/, "") : ASSET_BASE;

  useEffect(() => {
    setSelectedSub("All");
  }, [category]);

  useEffect(() => {
    const fetchGames = async () => {
      try {
        const res = await fetch(`${QUANTUM_BASE}/api/v1/casino/games`);
        if (res.ok) {
          const data = await res.json();
          setGames(data.games || data);
        }
      } catch (error) {
        console.error("Failed to fetch casino games:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchGames();
  }, []);

  if (loading) return <div className="animate-pulse text-gold text-xs text-center py-6">Loading Slot Engine...</div>;

  // 1. Filter by Main Category (Slot vs Rest)
  const mainFilteredGames = games.filter((game: any) => {
    const gameCategory = (game.category || game.type || "").toLowerCase();
    if (category === "slot") return gameCategory.includes("slot");
    if (category === "casino") return !gameCategory.includes("slot");
    return true;
  });

  // 2. Extract Unique Sub-Categories (Providers or Sub-types)
  const rawSubCategories = mainFilteredGames.map((g: any) => g.category || g.provider || "Other");
  const uniqueSubCategories = ["All", ...Array.from(new Set(rawSubCategories))];

  // 3. Final Filter based on selected pill
  const finalGames = selectedSub === "All" 
    ? mainFilteredGames 
    : mainFilteredGames.filter((g: any) => (g.category || g.provider || "Other") === selectedSub);

  return (
    <div className="flex flex-col gap-4 w-full min-w-0 overflow-hidden">
      {/* Horizontal Scrollable Filter Bar */}
      {category === "casino" && uniqueSubCategories.length > 1 && (
        <div className="flex w-full overflow-x-auto no-scrollbar gap-2 px-1 pb-2">
          {uniqueSubCategories.map((sub: any, idx) => (
            <button
              key={idx}
              onClick={() => setSelectedSub(sub)}
              className={`flex-shrink-0 px-4 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                selectedSub === sub 
                  ? "bg-gold text-black shadow-[0_0_10px_rgba(251,191,36,0.5)]" 
                  : "bg-white/5 border border-white/10 text-text-dim hover:text-white hover:bg-white/10"
              }`}
            >
              {sub.toUpperCase()}
            </button>
          ))}
        </div>
      )}

      {/* Render Final Games */}
      <div className="grid grid-cols-3 gap-2 md:gap-3">
        {finalGames.map((game: any, i) => (
          <div key={i} onClick={() => onLaunchGame(game.id || game.name)} className="relative transition-transform active:scale-95 cursor-pointer w-full">
            <div className="aspect-square w-full">
              <img src={game.thumbnail_url ? `${cleanAssetBase}/${game.thumbnail_url.replace(/^\//, '')}` : `https://placehold.co/150x150/1f2937/ffffff?text=Game`} alt={game.name} className="h-full w-full object-cover rounded-xl" />
            </div>
            <div className="p-1.5 text-center">
              <h3 className="truncate text-[10px] font-bold text-white">{game.name}</h3>
            </div>
          </div>
        ))}
        {finalGames.length === 0 && (
          <div className="col-span-3 py-10 text-center text-sm text-text-dim">No games found.</div>
        )}
      </div>
    </div>
  );
}
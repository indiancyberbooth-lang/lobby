"use client";

import { Landmark, Smartphone, CircleDollarSign } from "lucide-react";

export type PaymentMethod = "upi" | "bank" | "usdt";

interface PaymentMethodSelectorProps {
  selectedMethod: PaymentMethod;
  onSelect: (method: PaymentMethod) => void;
}

export const PaymentMethodSelector = ({
  selectedMethod,
  onSelect,
}: PaymentMethodSelectorProps) => {
  const methods = [
    { id: "upi", label: "UPI", icon: Smartphone },
    { id: "bank", label: "Bank Transfer", icon: Landmark },
    { id: "usdt", label: "USDT (TRC20)", icon: CircleDollarSign },
  ];

  return (
    <div className="grid grid-cols-3 gap-3">
      {methods.map((method) => {
        const isSelected = selectedMethod === method.id;
        const Icon = method.icon;

        return (
          <button
            key={method.id}
            onClick={() => onSelect(method.id as PaymentMethod)}
            className={`flex flex-col items-center justify-center space-y-2 rounded-xl border p-4 transition-all ${
              isSelected
                ? "border-gold bg-white/10 text-gold shadow-[0_0_15px_rgba(251,191,36,0.15)]"
                : "border-white/5 bg-bg-card text-text-dim hover:bg-white/5 hover:text-white"
            }`}
          >
            <Icon size={24} className={isSelected ? "text-gold" : "text-text-dim"} />
            <span className="text-xs font-semibold">{method.label}</span>
          </button>
        );
      })}
    </div>
  );
};